document.addEventListener('DOMContentLoaded', () => {
    const notificationContainer = document.getElementById('notification-container');
    const infoModalOverlay = document.getElementById('info-modal-overlay');
    const infoModalText = document.getElementById('info-modal-text');
    const infoModalCloseBtn = document.getElementById('info-modal-close-btn');
    const infoModalCloseIcon = document.getElementById('info-modal-close-icon');
    const statusElements = {
        serviceStatus: document.getElementById('service-status'),
        cpuUsage: document.getElementById('cpu-usage'),
        systemCpuLoad: document.getElementById('system-cpu-load'),
        ramUsage: document.getElementById('ram-usage'),
        currentProfileMode: document.getElementById('current-profile-mode'),
        serviceBanner: document.getElementById('service-banner'),
    };
    const moduleInfoElements = {
        moduleName: document.getElementById('module-name'),
        moduleVersion: document.getElementById('module-version'),
        moduleDeveloper: document.getElementById('module-developer'),
        modulePlugins: document.getElementById('module-plugins'),
    };
    const deviceInfoElements = {
        deviceSdkVersion: document.getElementById('device-sdk-version'),
    };
    const refreshButton = document.getElementById('refresh-button');
    const actionButtons = document.querySelectorAll('.action-button[data-command], .action-card[data-command]');
    const exitButton = document.getElementById('exit-button');
    const telegramBtn = document.getElementById('telegram-button');
    const shutdownLoader = document.getElementById('shutdown-loader');
    const themeToggleBtn = document.getElementById('theme-toggle-btn');
    const langSelectionBar = document.getElementById('lang-selection-bar');
    const langSelectedValue = document.getElementById('lang-selected-value');
    const bottomNav = document.getElementById('bottom-nav');
    const navButtons = bottomNav.querySelectorAll('.nav-btn');
    const viewContents = document.querySelectorAll('.view-content');
    const settingsNavBtn = document.getElementById('settings-nav-btn');
    const settingsModalOverlay = document.getElementById('settings-modal-overlay');
    const settingsModalCloseBtn = document.getElementById('settings-modal-close-btn');
    const settingsLinks = document.querySelectorAll('.settings-link');
    const settingsPages = document.querySelectorAll('.settings-page');
    const cpuTraceToggle = document.getElementById('cpu-trace-toggle');
    const cpuTraceGrid = document.getElementById('cpu-trace-grid');
    const cpuGraphCanvas = document.getElementById('cpu-usage-graph');
    const cpuAvgLoad = document.getElementById('cpu-avg-load');
    const cpuTopProcessesContainer = document.getElementById('cpu-top-processes');
    const standbyToggle = document.getElementById('standby-toggle');
    const shutdownTimeItem = document.getElementById('shutdown-time-item');
    const warningRamInput = document.getElementById('warning_ram_perc-input');
    const criticalRamInput = document.getElementById('critical_ram_perc-input');
    const saveRamBtn = document.getElementById('save-ram-thresholds-btn');
    const ramManagerToggle = document.getElementById('ram_manager-toggle');
    const eglToggle = document.getElementById('egl-preloader-toggle');
    const eglTypeContainer = document.getElementById('egl-type-container');
    const exitConfirmModal = document.getElementById('exit-confirm-modal');
    const exitConfirmReloadBtn = document.getElementById('exit-confirm-reload');
    const exitConfirmContinueBtn = document.getElementById('exit-confirm-continue');
    const launcherWarningModal = document.getElementById('launcher-warning-modal');
    const launcherWarningAcceptBtn = document.getElementById('launcher-warning-accept');
    const launcherWarningNevermindBtn = document.getElementById('launcher-warning-nevermind');
    const gameListContainer = document.getElementById('game-list-container');
    const saveGameListButton = document.getElementById('save-game-list-button');
    const gameListSearch = document.getElementById('game-list-search');
    const viewportWidthInput = document.getElementById('viewport-width-input');
    const viewportApplyBtn = document.getElementById('apply-viewport-btn');
    const viewportResetBtn = document.getElementById('reset-viewport-btn');
    const metaViewport = document.querySelector('meta[name="viewport"]');
    let notificationTimeout;
    let translations = {};
    let isServiceRunning = false;
    let settingsChanged = false;
    let cpuTraceInterval = null;
    let cpuHistory = [];
    const MAX_HISTORY_POINTS = 100;
    let currentOS = 'Unknown';
    let deviceSdkVersion = 0;
    let launcherWarningAccepted = false;
    let masterGameListCache = new Set();
    let installedPackagesCache = new Set();
    function showNotification(message, type = 'success', duration = 4000) {
        if (notificationTimeout) clearTimeout(notificationTimeout);
        notificationContainer.innerHTML = message.replace(/\n/g, '<br>');
        notificationContainer.className = 'show ' + type;
        notificationTimeout = setTimeout(() => {
            notificationContainer.className = notificationContainer.className.replace('show', '');
        }, duration);
    }
    function openInfoModal(text) {
        if(infoModalText) infoModalText.innerHTML = text;
        if(infoModalOverlay) infoModalOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    function closeInfoModal() {
        if(infoModalOverlay) infoModalOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }
    if(infoModalCloseBtn) infoModalCloseBtn.addEventListener('click', closeInfoModal);
    if(infoModalCloseIcon) infoModalCloseIcon.addEventListener('click', closeInfoModal);
    if(infoModalOverlay) infoModalOverlay.addEventListener('click', (e) => { if (e.target === infoModalOverlay) closeInfoModal(); });
    function parseSafeJSON(text) {
        if (!text) return {};
        try {
            let cleanText = text.replace(/[\x00-\x09\x0B\x0C\x0E-\x1F\x7F]/g, '');
            const firstBrace = cleanText.indexOf('{');
            const lastBrace = cleanText.lastIndexOf('}');
            if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
                cleanText = cleanText.substring(firstBrace, lastBrace + 1);
            }
            return JSON.parse(cleanText);
        } catch (e) {
            throw e;
        }
    }
    async function handleApiCall(url, options = {}, buttonElement = null) {
        if (buttonElement) {
            buttonElement.classList.add('loading');
            buttonElement.disabled = true;
        }
        try {
            const response = await fetch(url, options);
            if (url === '/api/exit' && response.ok) {
                document.body.classList.add('server-down');
                setTimeout(() => location.reload(), 1500);
                return;
            }
            const text = await response.text();
            let data;
            try {
                data = parseSafeJSON(text);
            } catch (e) {
                if (text.includes('"status":"success"')) {
                    data = { status: 'success', output: 'Command executed' };
                } else {
                    throw new Error("Invalid server response structure");
                }
            }
            if (!response.ok || data.status !== 'success') {
                const error = new Error(data.message || 'API operation failed');
                error.data = data;
                throw error;
            }
            return data;
        } catch (error) {
            if (error.name !== 'AbortError' && error instanceof TypeError && !error.message.includes("JSON")) {
                showNotification('Server unreachable.', 'error');
                document.body.classList.add('server-down');
            }
            throw error;
        } finally {
            if (buttonElement && url !== '/api/exit') {
                buttonElement.classList.remove('loading');
                buttonElement.disabled = false;
            }
        }
    }
    async function saveSetting(file, key, value) {
        const url = '/api/save-setting';
        const options = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ file, key, value })
        };
        try {
            await handleApiCall(url, options);
            if (key === 'lite_mode') {
                document.body.classList.toggle('lite-mode-active', value === '1');
            }
            await loadAllSettings();
            const reloadRequiredKeys = ['hw_renderer', 'hw_backend_renderer', 'hw_composition', 'bypass_dynamic_refresh_rate', 'job_opt', 'pubg_config_enable'];
            if (isServiceRunning && reloadRequiredKeys.includes(key)) {
                showNotification(translations['reload_required'] || 'Setting saved. Press "Reload" to apply.', 'info', 6000);
                settingsChanged = true;
            } else {
                showNotification(translations['settings_saved'] || 'Setting Saved', 'success', 2000);
            }
        } catch (error) {
            showNotification(error.message, 'error');
            if (key === 'lite_mode') await loadAllSettings(); 
        }
    }
    function checkSdkRequirements() {
        if (deviceSdkVersion === 0) return;
        document.querySelectorAll('[data-min-sdk]').forEach(item => {
            const minSdk = parseInt(item.dataset.minSdk, 10);
            const toggle = item.querySelector('input[type="checkbox"]');
            if (deviceSdkVersion < minSdk) {
                item.classList.add('disabled');
                if (toggle && toggle.checked) {
                    toggle.checked = false;
                    const offValue = toggle.dataset.off || 'N';
                    saveSetting(toggle.dataset.file, toggle.dataset.key, offValue);
                }
            } else {
                item.classList.remove('disabled');
            }
        });
    }
    function updateRamDependency() {
        if (!ramManagerToggle) return;
        const isRamEnabled = ramManagerToggle.checked;
        const dependents = document.querySelectorAll('.ram-dependent');
        dependents.forEach(el => {
            if (isRamEnabled) {
                const minSdk = el.dataset.minSdk ? parseInt(el.dataset.minSdk, 10) : 0;
                if (deviceSdkVersion >= minSdk || minSdk === 0) {
                    el.classList.remove('disabled');
                }
            } else {
                el.classList.add('disabled');
            }
        });
    }
    function updateEglDependency() {
        if (!eglToggle || !eglTypeContainer) return;
        if (eglToggle.checked) {
            eglTypeContainer.classList.remove('invisible');
        } else {
            eglTypeContainer.classList.add('invisible');
        }
    }
    function updateGroupedSettings() {
        const swappyContainer = document.getElementById('swappy-delta-rt-container');
        const targetFrameRateItem = document.getElementById('target-frame-rate-item');
        if (swappyContainer && targetFrameRateItem) {
            const selectedValue = swappyContainer.querySelector('.selected-value').textContent.toLowerCase();
            const isStopped = selectedValue.includes('stop');
            targetFrameRateItem.classList.toggle('disabled', isStopped);
        }
        const bypassToggle = document.getElementById('bypass_dynamic_refresh_rate-toggle');
        const deviceRefreshRateItem = document.getElementById('device-refresh-rate-item');
        const deviceGroupItem = document.getElementById('device-group-item');
        if (bypassToggle) {
            const isBypassEnabled = bypassToggle.checked;
            if (deviceRefreshRateItem) deviceRefreshRateItem.classList.toggle('disabled', !isBypassEnabled);
            if (deviceGroupItem) deviceGroupItem.classList.toggle('disabled', !isBypassEnabled);
        }
        const gamePreloadingToggle = document.getElementById('game-preloading-toggle');
        const shaderPreloadItem = document.getElementById('shader-preload-size-item');
        if (gamePreloadingToggle && shaderPreloadItem) {
            shaderPreloadItem.classList.toggle('disabled', !gamePreloadingToggle.checked);
        }
    }
    document.querySelectorAll('[data-key]').forEach(element => {
        const file = element.dataset.file;
        const key = element.dataset.key;
        if (element.type === 'checkbox') {
            element.addEventListener('change', (e) => {
                const value = e.target.checked ? (e.target.dataset.on || 'Y') : (e.target.dataset.off || 'N');
                saveSetting(file, key, value);
                if (key === 'ram_manager') updateRamDependency();
                if (key === 'egl_preloader') updateEglDependency();
                if (key === 'bypass_dynamic_refresh_rate') updateGroupedSettings();
                if (key === 'game_preloading') updateGroupedSettings();
            });
        } else if (element.tagName === 'INPUT' && (element.type === 'text' || element.type === 'number')) {
             let debounceTimer;
             element.addEventListener('input', (e) => {
                clearTimeout(debounceTimer);
                const slider = document.getElementById(`${key}-slider`);
                if (slider) slider.value = e.target.value;
                 if(element.dataset.key !== "warning_ram_perc" && element.dataset.key !== "critical_ram_perc") {
                    debounceTimer = setTimeout(() => saveSetting(file, key, e.target.value), 800);
                 }
            });
        } else if (element.classList.contains('bar-selection') && element.id !== 'lang-selection-bar') {
            setupBarSelection(element, (button) => {
                const value = button.dataset.value;
                element.querySelector('.selected-value').textContent = button.textContent;
                saveSetting(file, key, value);
                if (key === 'swappy-delta_rt') updateGroupedSettings();
            });
        }
    });
    function setLanguage(lang) {
        document.documentElement.lang = lang;
        document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
        document.querySelectorAll('[data-lang-key]').forEach(el => {
            const key = el.dataset.langKey;
            const translation = translations[key];
            if (translation) {
                const icon = el.querySelector('i');
                const textNode = Array.from(el.childNodes).find(node => node.nodeType === Node.TEXT_NODE);
                if (icon && textNode) {
                    textNode.nodeValue = ` ${translation}`;
                } else if (icon) {
                    el.appendChild(document.createTextNode(` ${translation}`)); 
                } else {
                    el.textContent = translation;
                }
            }
        });
        if (langSelectedValue) langSelectedValue.textContent = lang.toUpperCase();
        localStorage.setItem('language', lang);
    }
    async function loadLanguage(lang) {
        try {
            const response = await fetch(`/assets/translate/${lang}.json`); 
            if (!response.ok) throw new Error(`Failed to load ${lang}.json`);
            translations = await response.json();
            setLanguage(lang);
        } catch (error) {
            if (lang !== 'en') await loadLanguage('en');
            else translations = {};
        }
    }
    if (langSelectionBar) {
        setupBarSelection(langSelectionBar, (button) => {
            const lang = button.dataset.lang;
            loadLanguage(lang);
        });
    }
    function applyTheme(isLight) {
        document.body.classList.toggle('light-theme', isLight);
        themeToggleBtn.innerHTML = isLight ? '<i class="fas fa-moon"></i>' : '<i class="fas fa-sun"></i>';
        localStorage.setItem('theme', isLight ? 'light' : 'dark');
        if (cpuTraceToggle.checked) drawCpuGraph();
    }
    themeToggleBtn.addEventListener('click', () => applyTheme(!document.body.classList.contains('light-theme')));
    navButtons.forEach(button => {
        if (button.id === 'settings-nav-btn') return;
        button.addEventListener('click', () => {
            const viewId = button.dataset.view;
            navButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            viewContents.forEach(view => view.classList.remove('active'));
            document.getElementById(viewId).classList.add('active');
            if (viewId === 'gamelist-view') loadGameList();
        });
    });
    settingsNavBtn.addEventListener('click', () => settingsModalOverlay.classList.add('active'));
    settingsModalCloseBtn.addEventListener('click', () => settingsModalOverlay.classList.remove('active'));
    settingsModalOverlay.addEventListener('click', (e) => {
        if (e.target === settingsModalOverlay) settingsModalOverlay.classList.remove('active');
    });
    function activateSettingsPage(pageId) {
        settingsModalOverlay.classList.remove('active');
        document.getElementById('home-view').classList.remove('active');
        document.getElementById('gamelist-view').classList.remove('active');
        document.getElementById('settings-view').classList.add('active');
        navButtons.forEach(btn => btn.classList.remove('active'));
        settingsNavBtn.classList.add('active');
        settingsPages.forEach(page => page.classList.remove('active'));
        const targetPage = document.getElementById(pageId);
        if (targetPage) targetPage.classList.add('active');
    }
    settingsLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const pageId = link.dataset.page;
            if (pageId === 'launcher-page' && !launcherWarningAccepted) {
                settingsModalOverlay.classList.remove('active');
                if (launcherWarningModal) launcherWarningModal.style.display = 'flex';
                return;
            }
            activateSettingsPage(pageId);
        });
    });
    if (launcherWarningAcceptBtn) {
        launcherWarningAcceptBtn.addEventListener('click', () => {
            launcherWarningAccepted = true;
            launcherWarningModal.style.display = 'none';
            activateSettingsPage('launcher-page');
        });
    }
    if (launcherWarningNevermindBtn) {
        launcherWarningNevermindBtn.addEventListener('click', () => {
            launcherWarningModal.style.display = 'none';
        });
    }
    function setupBarSelection(barElement, onSelectCallback) {
        const optionButtons = barElement.querySelectorAll('.option-button');
        const closeButton = barElement.querySelector('.options-close-btn');

        barElement.addEventListener('click', (e) => {
            if (barElement.closest('.disabled') || barElement.classList.contains('invisible')) return;
            if (closeButton && closeButton.contains(e.target)) return;
            e.stopPropagation();

            const wasActive = barElement.classList.contains('active');

            document.querySelectorAll('.bar-selection.active').forEach(other => {
                if (other !== barElement) {
                    other.classList.remove('active');
                    other.classList.remove('open-up');
                }
            });

            if (wasActive) {
                barElement.classList.remove('active');
                barElement.classList.remove('open-up');
                return;
            }

            const rect = barElement.getBoundingClientRect();
            const spaceBelow = window.innerHeight - rect.bottom;
            const dropdownHeight = 200; 
            const spaceAbove = rect.top;

            if (spaceBelow < dropdownHeight && spaceAbove > spaceBelow) {
                barElement.classList.add('open-up');
            } else {
                barElement.classList.remove('open-up');
            }
            
            barElement.classList.add('active');
        });

        optionButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.stopPropagation();
                onSelectCallback(button);
                barElement.classList.remove('active');
                barElement.classList.remove('open-up');
            });
        });

        if (closeButton) {
            closeButton.addEventListener('click', (e) => { 
                e.stopPropagation(); 
                barElement.classList.remove('active'); 
                barElement.classList.remove('open-up');
            });
        }
    }

    document.addEventListener('click', (e) => {
        document.querySelectorAll('.bar-selection.active').forEach(bar => {
            if (!bar.contains(e.target)) {
                bar.classList.remove('active');
                bar.classList.remove('open-up');
            }
        });
        if (e.target.matches('.fa-info-circle')) {
            const infoKey = e.target.dataset.infoKey;
            const translation = translations[infoKey] || "No description available for this setting.";
            openInfoModal(translation);
        }
        if (e.target === exitConfirmModal || (launcherWarningModal && e.target === launcherWarningModal)) {
            exitConfirmModal.style.display = 'none';
            if (launcherWarningModal) launcherWarningModal.style.display = 'none';
        }
    });
    document.querySelectorAll('.range-slider').forEach(slider => {
        const input = slider.nextElementSibling || document.getElementById(slider.id.replace('-slider', '-input'));
        if (input && input.classList.contains('range-value-input')) {
            slider.addEventListener('input', (e) => {
                input.value = e.target.value;
                input.dispatchEvent(new Event('input', { bubbles:true, cancelable:true }));
            });
        }
    });
    if (actionButtons) {
        actionButtons.forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const button = e.currentTarget; 
                const command = button.dataset.command;
                if (!command) return;
                if (command === 'uninstall') {
                    const confirmAction = confirm(translations['confirm_uninstall'] || "Are you sure you want to uninstall?");
                    if (!confirmAction) return;
                }
                try {
                    await handleApiCall(`/api/${command}`, {}, button);
                    showNotification((translations['command_success'] || 'Command executed successfully') + `: ${command}`, 'success');
                    setTimeout(updateStatusAndModuleInfo, 1000);
                    if (command === 'reload-settings') {
                        settingsChanged = false;
                        await loadAllSettings();
                    }
                } catch (error) {
                    showNotification(error.message || 'Action failed', 'error');
                }
            });
        });
    }
    if (refreshButton) {
        refreshButton.addEventListener('click', async () => {
            const icon = refreshButton.querySelector('i');
            if(icon) icon.classList.add('fa-spin');
            try {
                await initialize(true);
                showNotification(translations['refreshed'] || 'Dashboard refreshed', 'success');
            } catch (e) {
                showNotification('Refresh failed', 'error');
            } finally {
                if(icon) icon.classList.remove('fa-spin');
            }
        });
    }
    if (telegramBtn) {
        telegramBtn.addEventListener('click', () => {
            handleApiCall('/api/open-telegram')
                .catch(() => {
                    window.open('https://t.me/Youngupdatesource', '_blank');
                });
        });
    }
    if (exitButton) {
        exitButton.addEventListener('click', () => {
            if (settingsChanged) {
                if (exitConfirmModal) exitConfirmModal.style.display = 'flex';
            } else {
                performExit();
            }
        });
    }
    if (exitConfirmReloadBtn) {
        exitConfirmReloadBtn.addEventListener('click', async () => {
            try {
                await handleApiCall('/api/reload-settings', {}, exitConfirmReloadBtn);
                performExit();
            } catch (e) {
                showNotification(e.message, 'error');
            }
        });
    }
    if (exitConfirmContinueBtn) {
        exitConfirmContinueBtn.addEventListener('click', () => {
            performExit();
        });
    }
    async function performExit() {
        try {
            await handleApiCall('/api/exit');
        } catch (e) {
            console.error(e);
        }
    }
    if (viewportApplyBtn && viewportWidthInput) {
        viewportApplyBtn.addEventListener('click', () => {
            const val = viewportWidthInput.value;
            if (val && metaViewport) {
                metaViewport.setAttribute('content', `width=${val}`);
                localStorage.setItem('viewport-width', val);
                showNotification('Viewport updated', 'success');
            }
        });
    }
    if (viewportResetBtn) {
        viewportResetBtn.addEventListener('click', () => {
            if (metaViewport) {
                metaViewport.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');
                if(viewportWidthInput) viewportWidthInput.value = '';
                localStorage.removeItem('viewport-width');
                showNotification('Viewport reset', 'info');
            }
        });
    }
    function drawCpuGraph() {
        const ctx = cpuGraphCanvas.getContext('2d');
        const width = cpuGraphCanvas.clientWidth;
        const height = cpuGraphCanvas.clientHeight;
        cpuGraphCanvas.width = width;
        cpuGraphCanvas.height = height;
        ctx.clearRect(0, 0, width, height);
        if (cpuHistory.length < 2) return;
        const isLightTheme = document.body.classList.contains('light-theme');
        const lineColor = isLightTheme ? getComputedStyle(document.documentElement).getPropertyValue('--light-accent') : getComputedStyle(document.documentElement).getPropertyValue('--dark-accent');
        const gradTop = isLightTheme ? 'rgba(0, 98, 255, 0.2)' : 'rgba(0, 242, 234, 0.2)';
        const gradBottom = isLightTheme ? 'rgba(0, 98, 255, 0.01)' : 'rgba(0, 242, 234, 0.01)';
        ctx.beginPath();
        const step = width / (MAX_HISTORY_POINTS - 1);
        ctx.moveTo(0, height - (cpuHistory[0] / 100) * height);
        for (let i = 1; i < cpuHistory.length; i++) {
            ctx.lineTo(i * step, height - (cpuHistory[i] / 100) * height);
        }
        ctx.strokeStyle = lineColor;
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.lineTo((cpuHistory.length - 1) * step, height);
        ctx.lineTo(0, height);
        ctx.closePath();
        const gradient = ctx.createLinearGradient(0, 0, 0, height);
        gradient.addColorStop(0, gradTop);
        gradient.addColorStop(1, gradBottom);
        ctx.fillStyle = gradient;
        ctx.fill();
    }
    function renderTopProcesses(processes) {
        cpuTopProcessesContainer.innerHTML = '';
        if (processes && processes.length > 0) {
            processes.slice(0, 5).forEach(proc => {
                const item = document.createElement('div');
                item.className = 'process-item';
                item.innerHTML = `<span class="process-name">${proc.name}</span><span class="process-usage">${proc.usage}%</span>`;
                cpuTopProcessesContainer.appendChild(item);
            });
        }
    }
    function setupCpuTrace() {
        cpuTraceGrid.innerHTML = '';
        for (let i = 0; i < 8; i++) {
            const coreEl = document.createElement('div');
            coreEl.className = 'cpu-core-box';
            coreEl.id = `cpu-core-${i}`;
            coreEl.style.display = 'none';
            coreEl.innerHTML = `
                <div class="cpu-core-label"><span>CPU ${i}</span><span class="cpu-core-temp" id="cpu-temp-${i}">--°C</span></div>
                <div class="cpu-core-freq-bar-container"><div class="cpu-core-freq-bar" id="cpu-freq-bar-${i}"></div></div>
                <div class="cpu-core-stats"><span class="cpu-core-freq" id="cpu-freq-${i}">0 MHz</span><span class="cpu-core-usage" id="cpu-usage-${i}">0%</span></div>
            `;
            cpuTraceGrid.appendChild(coreEl);
        }
        cpuTraceToggle.addEventListener('change', () => {
            if (cpuTraceToggle.checked) {
                if (!cpuTraceInterval) {
                    fetchCpuData();
                    cpuTraceInterval = setInterval(fetchCpuData, 2000);
                }
            } else {
                if (cpuTraceInterval) {
                    clearInterval(cpuTraceInterval);
                    cpuTraceInterval = null;
                }
            }
        });
    }
    async function fetchCpuData() {
        try {
            const [cpuData, topData] = await Promise.all([
                handleApiCall('/api/cpu-trace'),
                handleApiCall('/api/top-processes')
            ]);
            if (cpuData && cpuData.status === 'success') {
                cpuAvgLoad.textContent = `${cpuData.avg_usage || 0}%`;
                cpuHistory.push(cpuData.avg_usage || 0);
                if (cpuHistory.length > MAX_HISTORY_POINTS) cpuHistory.shift();
                drawCpuGraph();
                document.querySelectorAll('.cpu-core-box').forEach(el => el.style.display = 'none');
                cpuData.cpus.forEach(cpu => {
                    const coreEl = document.getElementById(`cpu-core-${cpu.core}`);
                    if (coreEl) {
                        coreEl.style.display = 'flex';
                        document.getElementById(`cpu-freq-${cpu.core}`).textContent = `${cpu.freq} MHz`;
                        document.getElementById(`cpu-temp-${cpu.core}`).textContent = cpu.temp !== 'N/A' ? `${cpu.temp}°C` : '--°C';
                        document.getElementById(`cpu-usage-${cpu.core}`).textContent = `${cpu.usage}%`;
                        const freqBar = document.getElementById(`cpu-freq-bar-${cpu.core}`);
                        if(freqBar) freqBar.style.width = `${cpu.usage}%`;
                    }
                });
            }
            if (topData && topData.status === 'success') renderTopProcesses(topData.processes);
        } catch (error) {
            if(cpuTraceInterval) clearInterval(cpuTraceInterval);
            cpuTraceInterval = null;
            cpuTraceToggle.checked = false;
        }
    }
    function setupWebUISettings() {
        standbyToggle.addEventListener('change', (e) => {
            shutdownTimeItem.classList.toggle('disabled', e.target.checked);
        });
        const savedWidth = localStorage.getItem('viewport-width');
        if (savedWidth && metaViewport) {
            metaViewport.setAttribute('content', `width=${savedWidth}`);
            if (viewportWidthInput) viewportWidthInput.value = savedWidth;
        }
    }
    function setupRamThresholds() {
        saveRamBtn.addEventListener('click', async () => {
            const warningVal = parseInt(warningRamInput.value, 10);
            const criticalVal = parseInt(criticalRamInput.value, 10);
            if (isNaN(warningVal) || isNaN(criticalVal) || warningVal < 5 || warningVal > 70 || criticalVal < 5 || criticalVal > 70) {
                showNotification('Values must be between 5 and 70.', 'error'); return;
            }
            if (warningVal <= criticalVal) {
                showNotification('Warning value must be greater than Critical value.', 'error'); return;
            }
            try {
                await handleApiCall('/api/save-ram-thresholds', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `warning=${warningVal}&critical=${criticalVal}`
                }, saveRamBtn);
                showNotification('RAM thresholds saved.', 'success');
                await loadAllSettings();
            } catch (error) {
                showNotification(error.message, 'error');
                await loadAllSettings();
            }
        });
    }
    async function loadGameList() {
        if (gameListContainer.dataset.loaded) return;
        gameListContainer.innerHTML = '<div class="loader-spinner"></div>';
        try {
            const data = await handleApiCall('/api/get-game-list-data');
            gameListContainer.innerHTML = '';
            masterGameListCache = new Set(data?.game_list || []); 
            installedPackagesCache = new Set(data?.all_packages || []);
            if (installedPackagesCache.size === 0) {
                gameListContainer.innerHTML = `<p style="text-align: center;">${translations['no_installed_apps'] || 'No installed applications found.'}</p>`;
            }
            Array.from(installedPackagesCache).sort().forEach(pkg => {
                const isChecked = masterGameListCache.has(pkg);
                const item = document.createElement('div');
                item.className = 'game-list-item';
                item.dataset.packageName = pkg;
                item.innerHTML = `
                    <label for="pkg-${pkg}" class="game-list-item-label">${pkg}</label>
                    <label class="custom-checkbox">
                        <input type="checkbox" id="pkg-${pkg}" value="${pkg}" ${isChecked ? 'checked' : ''}>
                        <span class="checkmark"></span>
                    </label>
                `;
                gameListContainer.appendChild(item);
            });
            gameListContainer.dataset.loaded = "true";
        } catch (error) {
            gameListContainer.innerHTML = `<p style="color: var(--danger-color);">${error.message}</p>`;
            delete gameListContainer.dataset.loaded;
        }
    }
    saveGameListButton.addEventListener('click', async (e) => {
        const checkedGames = Array.from(document.querySelectorAll('#game-list-container input:checked')).map(cb => cb.value);
        try {
            await handleApiCall('/api/save-game-list', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ games: checkedGames })
            }, saveGameListButton);
            showNotification(translations['game_list_saved'] || 'Game list saved successfully!', 'success');
        } catch (error) {
            showNotification(error.message, 'error');
        }
    });
    gameListSearch.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        gameListContainer.querySelectorAll('.game-list-item').forEach(item => {
            const packageName = item.dataset.packageName.toLowerCase();
            item.style.display = packageName.includes(searchTerm) ? 'flex' : 'none';
        });
    });
    async function loadModuleScripts() {
        try {
            const data = await handleApiCall('/api/get-module-scripts');
            if (data && data.status === 'success' && data.scripts) {
                const datalist = document.getElementById('module-scripts-list');
                datalist.innerHTML = '';
                data.scripts.forEach(scriptName => {
                    const option = document.createElement('option');
                    option.value = scriptName;
                    datalist.appendChild(option);
                });
            }
        } catch (e) {}
    }
    function setupActionBars() {
        const driverApplyButton = document.getElementById('driver-apply-button');
        const touchApplyButton = document.getElementById('touch-apply-button');
        const driverBar = document.getElementById('driver-selection-bar');
        const touchBar = document.getElementById('touch-selection-bar');
        if(driverBar) {
            setupBarSelection(driverBar, (button) => {
                const valEl = document.getElementById('driver-selected-value');
                if(valEl) valEl.textContent = button.textContent;
                if (driverApplyButton) driverApplyButton.dataset.param = button.dataset.param;
            });
        }
        if (driverApplyButton) driverApplyButton.addEventListener('click', e => {
            const param = e.currentTarget.dataset.param || 'reset';
            handleApiCall(`/api/driver?type=${param}`, {}, e.currentTarget)
                .then(() => showNotification('Driver settings applied', 'success'))
                .catch(err => showNotification(err.message, 'error'));
            saveWebuiLastSettings();
        });
        if(touchBar) {
            setupBarSelection(touchBar, (button) => {
                const valEl = document.getElementById('touch-selected-value');
                if(valEl) valEl.textContent = button.textContent;
                if (touchApplyButton) touchApplyButton.dataset.param = button.dataset.param;
            });
        }
        if (touchApplyButton) touchApplyButton.addEventListener('click', e => {
            const param = e.currentTarget.dataset.param || 'reset';
            handleApiCall(`/api/touch?level=${param}`, {}, e.currentTarget)
                .then(() => showNotification('Touch settings applied', 'success'))
                .catch(err => showNotification(err.message, 'error'));
            saveWebuiLastSettings();
        });
    }
    function saveWebuiLastSettings() {
        const touchSelectedValue = document.getElementById('touch-selected-value');
        const driverSelectedValue = document.getElementById('driver-selected-value');
        if (!touchSelectedValue || !driverSelectedValue) return;
        const payload = {
            touch  : touchSelectedValue.textContent.toLowerCase(),
            driver : driverSelectedValue.textContent.toLowerCase()
        };
        fetch('/api/save-webuilast-settings', {
            method : 'POST',
            headers: { 'Content-Type': 'application/json' },
            body   : JSON.stringify(payload)
        }).catch(()=>{});
    }
    async function updateStatusAndModuleInfo() {
        try {
            const statusData = await handleApiCall('/api/get-full-status');
            const serviceBanner = document.getElementById('service-banner');
            if (statusData && statusData.status === 'success' && statusData.details) {
                const serviceStatus = statusData.details.service_status || 'stopped';
                isServiceRunning = serviceStatus.toLowerCase() === 'running';
                
                if (statusElements.serviceStatus) {
                    statusElements.serviceStatus.textContent = isServiceRunning ? 'Active' : 'Stopped';
                    statusElements.serviceStatus.className = `hero-status status-${serviceStatus.toLowerCase()}`;
                }

                if (serviceBanner) {
                    const targetImage = isServiceRunning ? '/img/running.webp' : '/img/stopped.webp';
                    if (!serviceBanner.src.endsWith(targetImage)) {
                        serviceBanner.src = targetImage;
                    }
                }

                const serviceCpuStr = statusData.details.service_cpu_usage || '0%';
                const systemCpuStr = statusData.details.system_cpu_usage || '0%';
                const ramUsageStr = statusData.details.ram_usage || '0%';

                if (statusElements.cpuUsage) statusElements.cpuUsage.textContent = serviceCpuStr;
                if (statusElements.systemCpuLoad) statusElements.systemCpuLoad.textContent = systemCpuStr;
                if (statusElements.ramUsage) statusElements.ramUsage.textContent = ramUsageStr;

                const setChartPercent = (elementId, valueStr) => {
                    const el = document.getElementById(elementId);
                    if (el) {
                        const val = parseFloat(valueStr) || 0;
                        el.style.setProperty('--p', val);
                    }
                };

                setChartPercent('svc-cpu-chart', serviceCpuStr);
                setChartPercent('sys-cpu-chart', systemCpuStr);
                setChartPercent('ram-chart', ramUsageStr);

            }
        } catch (e) { 
            isServiceRunning = false; 
            const serviceBanner = document.getElementById('service-banner');
            if (serviceBanner && !serviceBanner.src.endsWith('/img/stopped.webp')) {
                serviceBanner.src = '/img/stopped.webp';
            }
        }
        
        try {
            const logData = await handleApiCall('/api/get-log-info');
            if (logData && logData.status === 'success') {
                const log = logData.log_content || "";
                if (moduleInfoElements.moduleName) moduleInfoElements.moduleName.textContent = (log.match(/• Name\s+:\s+(.*)/i) || [])[1] || 'N/A';
                if (moduleInfoElements.moduleVersion) moduleInfoElements.moduleVersion.textContent = (log.match(/• Version\s+:\s+(.*)/i) || [])[1] || 'N/A';
                if (moduleInfoElements.moduleDeveloper) moduleInfoElements.moduleDeveloper.textContent = (log.match(/• Developer\s+:\s+(.*)/i) || [])[1] || 'N/A';
                if (moduleInfoElements.modulePlugins) moduleInfoElements.modulePlugins.textContent = (log.match(/• Plugins-installed:\s*(.*)/i) || [])[1] || 'N/A';
                const profileLines = log.split('\n').filter(line => line.includes('Activated') || line.includes('Deactivated'));
                if (profileLines.length > 0) {
                    const lastProfile = profileLines[profileLines.length - 1];
                    if (statusElements.currentProfileMode) statusElements.currentProfileMode.textContent = lastProfile.includes('Activated') ? 'Performance' : 'Balanced';
                } else {
                    if (statusElements.currentProfileMode) statusElements.currentProfileMode.textContent = 'Unknown';
                }
            }
        } catch (e) {}
        updateUnsupportedSettings();
    }
        function renderOsTunningTab() {
        const osTunningSettingsLink = document.getElementById('os-tunning-settings-link');
        const miuiSettings = document.getElementById('miui-hyperos-settings');
        const xosSettings = document.getElementById('xos-settings');
        const funtouchosSettings = document.getElementById('funtouchos-settings');
        const colorosSettings = document.getElementById('coloros-settings');
        const unsupportedSettings = document.getElementById('unsupported-os-settings');

        document.querySelectorAll('.os-specific-settings').forEach(el => el.style.display = 'none');
        if(osTunningSettingsLink) osTunningSettingsLink.style.display = 'none';

        let hasOsSpecificSettings = false;
        if (currentOS === 'MIUI' || currentOS === 'HyperOS') { 
            if(miuiSettings) miuiSettings.style.display = 'block'; 
            hasOsSpecificSettings = true; 
        } 
        else if (currentOS === 'XOS' || currentOS === 'HiOS' || currentOS === 'ItelOS') { 
            if(xosSettings) xosSettings.style.display = 'block'; 
            hasOsSpecificSettings = true; 
        } 
        else if (currentOS === 'FuntouchOS' || currentOS === 'OriginOS') { 
            if(funtouchosSettings) funtouchosSettings.style.display = 'block'; 
            hasOsSpecificSettings = true; 
        } 
        else if (currentOS === 'ColorOS' || currentOS === 'RealmeUI' || currentOS === 'OxygenOS') { 
            if(colorosSettings) colorosSettings.style.display = 'block'; 
            hasOsSpecificSettings = true; 
        } 
        else if (currentOS === 'MagicOS' || currentOS === 'EMUI' || currentOS === 'HarmonyOS') {
            if(unsupportedSettings) {
                unsupportedSettings.innerHTML = `<p data-lang-key="no_os_settings">No specific tunning available for ${currentOS} yet.</p>`;
                unsupportedSettings.style.display = 'block';
            }
            hasOsSpecificSettings = true;
        }
        else if (currentOS !== 'Unknown' && currentOS !== 'Motorola') { 
            if(unsupportedSettings) unsupportedSettings.style.display = 'block'; 
            hasOsSpecificSettings = true; 
        }
        if (hasOsSpecificSettings && osTunningSettingsLink) osTunningSettingsLink.style.display = 'flex';
    }

    async function updateDeviceInfo() {
        try {
            const response = await handleApiCall('/api/get-device-info');
            const deviceData = response.data;
            currentOS = deviceData.os_name || 'Unknown';
            deviceSdkVersion = parseInt(deviceData.sdk_version || '0', 10);
            if (deviceInfoElements.deviceSdkVersion) deviceInfoElements.deviceSdkVersion.textContent = deviceSdkVersion;
            renderOsTunningTab();
        } catch(e) {}
    }
    function updateUnsupportedSettings() {
        checkSdkRequirements();
        updateRamDependency();
        updateEglDependency();
        updateGroupedSettings();
    }
    async function loadAllSettings() {
        try {
            const data = await handleApiCall('/api/get-all-settings');
            if (data && data.status === 'success') {
                const settings = data.settings;
                for (const key in settings) {
                    const value = settings[key];
                    document.querySelectorAll(`[data-key="${key}"]`).forEach(element => {
                        if (element.type === 'checkbox') {
                            element.checked = (value.toLowerCase() === (element.dataset.on || 'Y').toLowerCase());
                        } else if (element.tagName === 'INPUT' && (element.type === 'text' || element.type === 'number')) {
                            element.value = value;
                            const slider = document.getElementById(`${key}-slider`);
                            if (slider) slider.value = value;
                        } else if (element.classList.contains('bar-selection')) {
                            const selectedValueEl = element.querySelector('.selected-value');
                            const option = element.querySelector(`[data-value="${value}"]`);
                            if (selectedValueEl) selectedValueEl.textContent = option ? option.textContent : value;
                        }
                    });
                }
                document.body.classList.toggle('lite-mode-active', settings.lite_mode === '1');
                const standbyVal = settings.standby === 'true';
                if(standbyToggle) standbyToggle.checked = standbyVal;
                if(shutdownTimeItem) shutdownTimeItem.classList.toggle('disabled', standbyVal);
                if (settings.warning_ram_perc && warningRamInput) warningRamInput.value = settings.warning_ram_perc;
                if (settings.critical_ram_perc && criticalRamInput) criticalRamInput.value = settings.critical_ram_perc;
                updateUnsupportedSettings();
            }
        } catch (e) {}
    }
    async function loadWebuiLastSettings() {
        const touchSelectedValue = document.getElementById('touch-selected-value');
        const driverSelectedValue = document.getElementById('driver-selected-value');
        let touchVal = 'reset', driverVal = 'reset';
        try {
            const result = await handleApiCall('/api/get-webuilast-settings');
            if (result.status === 'success' && result.data) {
                let data = result.data;
                if (typeof data === 'string') { try { data = JSON.parse(data); } catch (e) {} }
                touchVal = data?.touch || 'reset';
                driverVal = data?.driver || 'reset';
            }
        } catch (error) {}
        const touchTextMap = { high: 'High', medium: 'Medium', low: 'Low', reset: 'Reset' };
        const driverTextMap = { game: 'Game', prelease: 'Pre-release', angle: 'Angle', reset: 'Reset' };
        if (touchSelectedValue) touchSelectedValue.textContent = touchTextMap[touchVal] || touchVal;
        if (driverSelectedValue) driverSelectedValue.textContent = driverTextMap[driverVal] || driverVal;
        if (document.getElementById('touch-apply-button')) document.getElementById('touch-apply-button').dataset.param = touchVal;
        if (document.getElementById('driver-apply-button')) document.getElementById('driver-apply-button').dataset.param = driverVal;
    }
    async function initialize(isRefresh = false) {
        const savedTheme = localStorage.getItem('theme');
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        applyTheme(savedTheme ? savedTheme === 'light' : !prefersDark);
        await loadLanguage(localStorage.getItem('language') || 'en');
        try {
            await Promise.all([
                updateDeviceInfo(),
                updateStatusAndModuleInfo(),
                loadModuleScripts(),
                loadAllSettings()
            ]);
            await loadWebuiLastSettings();
        } catch (error) {}
        if (!isRefresh) {
            setupCpuTrace();
            setupWebUISettings();
            setupRamThresholds();
            setupActionBars();
            setInterval(updateStatusAndModuleInfo, 30000);
        }
    }
    initialize();
});