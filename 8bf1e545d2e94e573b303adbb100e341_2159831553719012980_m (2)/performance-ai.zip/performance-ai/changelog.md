# perf-ai 更新日志 2.1 > 2.2

# - 使用更新的 Clang 修补 API 文件，从 19.0.0 > 21.0.1（Android NDK R29）
# - 修补的 API 插件附加组件版本：Ram Manager v7.0, Swappy Delta v7.0, Vmt Lite v3.0, Pid Finder v2.9

# - 优化 perf_service_@api 主逻辑
  • 将线程单数据同步替换为自主数据分配
  • 移除外部 Shell 调用 / 正则表达式，改用原生 C 以减少系统调用开销
  • 使用 qsort + 压缩十六进制减少游戏列表内存分配，实现更快且更小的分配
  • 添加智能取消工作线程功能，当脚本未使用多个线程时，会定期销毁未使用的线程
  • 改进写入 / 读取活动，将每次写入 shared_window 的 popen() 改为静态 popen()，直到服务关闭 / 停止
  • 清理日志机制，以处理繁忙活动并便于调试
  • 使用四舍五入参数 / 解释器 / if else 逻辑优化循环活动
  • 优化屏幕关闭检测机制（等待用户待机 1 分钟后再检查屏幕状态，避免在检查当前前台应用时高耗电）
  • 使用 __builtin_expect(!!(x), 0) 和 __builtin_expect(!!(x), 1) 减少 CPU 交互和预测
  • 优化编译器参数，利用热 / 冷 / 纯缓存提升编译器交互：
  -__attribute__((hot))
  -__attribute__((cold))
  -__attribute__((pure))
  ######
  • 使用 __attribute__((aligned(CACHELINE_SIZE))) 优化缓存对齐，以在新版 ARM 上获得更好的缓存分配
  • 改进系统守护进程机制，使用 XOR 加密防止重命名，提高安全性
  • 将前台检查间隔从 5 秒调整为 7 秒，以提高效率并避免系统繁忙标记
  • 修补 pid watcher 版本 2.5 > 2.9（在扫描、读取、信号调用、信号捕获方面的小改动，以提升游戏时的效率和稳定性）

# - 优化主 swappy_delta_api 运行时
  • 移除调试属性：
            setSystemProperty("debug.sf.prime_shader_cache.clipped_dimmed_image_layers", false);
            setSystemProperty("debug.sf.prime_shader_cache.clipped_layers", false);
            setSystemProperty("debug.sf.prime_shader_cache.edge_extension_shader", true);
            setSystemProperty("debug.sf.prime_shader_cache.hole_punch", false);
            setSystemProperty("debug.sf.prime_shader_cache.image_dimmed_layers", false);
            setSystemProperty("debug.sf.prime_shader_cache.image_layers", true);
            setSystemProperty("debug.sf.prime_shader_cache.pip_image_layers", false);
            setSystemProperty("debug.sf.prime_shader_cache.shadow_layers", true);
            setSystemProperty("debug.sf.prime_shader_cache.solid_dimmed_layers", false);
            setSystemProperty("debug.sf.prime_shader_cache.solid_layers", true);
            setSystemProperty("debug.sf.prime_shader_cache.transparent_image_dimmed_layers", false);
            以提升稳定性和游戏体验，不牺牲系统内置缓存机制
  • 改进 swappy_delta_api 缓存内存，减少 getprop / 系统调用使用，以降低低端设备或后台系统繁忙等待的开销
  • 调整脚本读取器，使用 inotify wait 监听 perf_service_api shared_window 功能的前台变化，减少后台 CPU 负载
  • 改进脚本计算和数据预测
  • 替换 Shell / bash 解析器为原生 C 解析器，提高效率
  • 使用 perf_service_api 的 shared_window 功能改进空闲检测
  • 清理编译器中未使用的参数，以减小二进制体积并提升后台运行性能
  • 智能内存分配，优化后台内存使用，高效保持游戏列表内存
  • 从专用版本中移除 ASM 操作标志，替换为单一高效 CPU 交互，减少后台 CPU 使用 40%
  • 改进数据检查或 grep，使脚本拥有更好的数据统计系统，用于计算和帧预测
  • 修复新 Android 版本中的数据崩溃问题
  • 调整部分空闲睡眠以提高效率

# - 优化 ram_manager_api 更新日志：
  • 通过管理 is_pid_alive 数据分配优化后台守护进程运行时，实现更快响应
  • 添加预测模型到内存管理器，提升内存释放检测
  • 修复并调整或移除旧版本中未使用的参数，使代码更简洁
  • 移除部分未使用的命令，标记为系统默认更优

# - 优化 dynamic_path_api 更新日志：
  • 优化文件扫描、过滤和数据分配，减少 CPU 负载
  • 与 vmt_lite 参数选项同步
  • 重构文件格式优先级，预加载重要文件而非垃圾文件（如 log、txt、backup、cloud 等）
  • 在收集 / 扫描后添加自销毁，再运行 vmt_lite 工具命令

# - 优化 vmt_lite 更新日志
  • 调整 mmaping / mmap() 以高效使用内存
  - 更新 native_lib 允许原生预加载应用库
  - 更新分叉、读取、写入、过滤机制，提升 CPU 交互
  - 通过 MADV_MERGEABLE 和 MADV_WILLNEED 优化预加载机制，标记共享内存并允许刷新（-z 功能）
  - 移除未使用的标志和浪费 CPU 周期的复杂机制
  - 添加自动睡眠 / 自动 sigsuspend，直到收到 sigstop 信号再清理缓存页
  - 添加自动设置后台优先级，避免干扰游戏会话

# - 优化 server api 更新日志：
  • 改进部分设备的 OS / ROM 检测（HyperOS、MIUI、HonorOS、ColorOS 等）
  • 添加线程信号处理器以支持异步工作
  • 改进数据发送
  • WebUI 更新日志：
  - 重构主 UI/UX 以提升用户体验
  - 为支持的 OS 添加运行设置
  - 更好的视觉效果
  - 移除未使用的编译标志并添加缓冲内存分配

# - 其他更新日志：
  • 为 HonorOS 添加绕过刷新率支持
  • 为 MIUI / HyperOS 添加新 OS 调优设置（热断路器、极速模式、调度加速）
  • 改进 start.sh 逻辑更新日志
  - 在精简模式未激活时使用 setsid 加快安装（在后台应用 appops 和系统限制）
  - 移除辅助函数中的部分未使用标志
  - 为 OS 运行设置添加预应用以提高效率
  - 修复在性能和均衡模式切换时的预加载清理
  - 修复并修补卸载脚本，使其与新版 start.sh 等脚本同步，实现干净卸载
# - 编译器日志更新日志
  • 将旧编译器标志参数（标记为专用）替换为新标志
  - [arm64-v8a]：添加 -moutline-atomics 以支持线程和检查 LSE（大系统扩展），提升线程、锁定等性能
  - 将 -flto=thin 改为完整 LTO（-flto）
  - 使用 llvm-objcopy 清理 API 元数据
  - 添加 -fvectorize 强制编译器积极启用自动向量化（将标准循环转换为 SIMD/NEON 指令），应用于 vmt_lite 和 swappy_delta_api
# - 次要 AXM（AX 管理器）更新日志
  • 在动作按钮上新增显示 UI、资源等
  • 添加开机后自动安装（需已设置相关选项，以便在重启后自动运行或启动）
