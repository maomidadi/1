# step 1🇬🇧:
# - Also check gamelist.txt to make sure whether the game package name is there, if there is, don't add it if you haven't added it yet
# - do not edit game_list_true.txt because those are the games found on your device (note if you install a new game it is recommended to reinstall so that game_list_true.txt is refreshed)
# - It is recommended to set the module first so that it adjusts itself and does not cause errors such as crashes, reboots itself because the preload is too large, etc.
# - after setting click install so that the script runs otherwise it will be a gimmick and not work
# - After that, click exit if the static script is running and if you want to open the web UI again, copy paste the command to open the web UI again.
# - additional information click on the logo (i) there will display a brief explanation of the features

# step 1🇮🇩:
# - cek juga gamelist.txt untuk memastikan apakah ada nama package game nya,jika ada jangan tambahkan kalau belum tambahkan
# - jangan edit game_list_true.txt karena itu adalah game yang ditemukan di device anda (note jika kamu menginstal game baru disarankan reinstall agar game_list_true.txt terefresh)
# - Disarankan menyetting module terlebih dahulu agar menyesuaikan sendiri dan tidak menyebabkan error seperti crash, reboot sendiri karena preload terlalu besar dll.
# - setelah menyetting klik install agar script berjalan jika tidak itu akan menjadi gimmik dan tidak bekerja
# - setelah itu klik exit jika statys script sudah running dan jika ingin membuka webuinya lagi copy pastle lagi command membuka webuinya
# - informasi tambahan klik logo (i) disitu akan menampilkan penjelasan singkat tentang fiturnya

# الخطوة 1🇸🇦: # - تحقق أيضًا من ملف gamelist.txt للتأكد من وجود اسم حزمة اللعبة. إذا كان موجودًا، فلا تُضِفْه إذا لم يكن موجودًا بالفعل.
# - لا تُعَدِّل ملف game_list_true.txt لأنه اللعبة الموجودة على جهازك (ملاحظة: إذا كنت تُثبِّت لعبة جديدة، فأعد تثبيتها لتحديث ملف game_list_true.txt).
 # - يُوصى بتهيئة الوحدة أولًا حتى تتكيف ولا تُسبِّب أخطاءً مثل الأعطال، أو إعادة التشغيل بسبب التحميل المسبق المفرط، وما إلى ذلك.
 # - بعد التهيئة، انقر على "تثبيت" لتشغيل البرنامج النصي. وإلا، فسيكون مجرد خدعة ولن يعمل.
 # - بعد ذلك، انقر على "خروج" إذا كان البرنامج النصي الثابت قيد التشغيل. إذا كنت ترغب في فتح واجهة مستخدم الويب مرة أخرى، فانسخ الأمر والصقه لفتح واجهة مستخدم الويب.
 # - لمزيد من المعلومات، انقر على شعار (i). سيعرض شرحًا موجزًا للميزات.


# step 2:
# Run Ai (manual)
sh /sdcard/performance-ai/start.sh --install

# kill process bg performance-ai/ uninstall (manual)

sh /sdcard/performance-ai/start.sh --uninstall

# list command (manual)
sh /sdcard/performance-ai/start.sh --help

# settings file directory (manual)
1. /sdcard/performance-ai/settings/
# if not found try
2. /storage/emulated/0/performance-ai/settings
# this a settings directory for user to adjust the settings by own user

# New step 2 more easy for user settings
# WEBUI (AUTO) support root / non root
sh /storage/emulated/0/performance-ai/start.sh --websettings

# step 3 webui(auto) easy settings and running
# after settings and install you can click exit button to exit webui menu for reducing cpu consuption

# Author: @reljawa
# Terimakasih 🙏🏻
# note Join channel Telegram untuk pertanyaan lebih lanjut 
Telegram channel : https://t.me/Youngupdatesource
support me : https://sociabuzz.com/reljawa/tribe