#!/system/bin/sh
RWD="/storage/emulated/0/performance-ai"
API_SETTINGS="$RWD/settings/api_settings.ini"
OS_SETTINGS="$RWD/settings/os_settings.ini"
SETTINGS_FILE="$RWD/settings/settings.ini"
GAME_LIST="$RWD/game_list_true.txt"

{
    pkill -15 -f vmt_lite
    pkill -15 -f ram_manager_api
    sleep 0.5
    pkill -9 -f vmt_lite
    find "$RWD"/emulated -maxdepth 1 -type f \( -name "*.pid" -o -name "*_dpid" -o -name "*vmtouch_batch.*" \) -delete
} >/dev/null 2>&1

b=$(getprop ro.build.version.release)
dnd_on=$(grep "^dnd_if_gaming=" "$SETTINGS_FILE" | cut -d "=" -f 2)
adaptive_saver=$(grep "^adaptive_power_saver=" "$API_SETTINGS" | cut -d "=" -f 2)
temp_limit=$(grep "^disable_templimit=" "$OS_SETTINGS" | cut -d "=" -f 2)
speed_mode_on=$(grep "^speed_mode=" "$OS_SETTINGS" | cut -d "=" -f 2)
perf_mode_on=$(grep "^allow_perf_mode=" "$OS_SETTINGS" | cut -d "=" -f 2)
bypass_high_temp=$(grep "^xos_bypass_hightemp_warn=" "$OS_SETTINGS" | cut -d "=" -f 2)
fos_hdr_disabler=$(grep "^fos_hdr_disabler=" "$OS_SETTINGS" | cut -d "=" -f 2)
cos_temp_protect=$(grep "^cos_temp_protect_disabler=" "$OS_SETTINGS" | cut -d "=" -f 2)
thermal_break=$(grep "^thermal_breaker=" "$OS_SETTINGS" | cut -d "=" -f 2)
sched_boost=$(grep "^sched_booster=" "$OS_SETTINGS" | cut -d "=" -f 2)

cmd notification post -S bigtext -i "file:///storage/emulated/0/performance-ai/img/banner.png" -t '[Perf AI 通知]' 'PerfAI_Tag' '⏳ 正在优化系统资源...
• 关闭后台应用... ♻️
• 准备均衡模式 ⚙️
敬请期待极致效率！🚀' >/dev/null 2>&1

{
    state_file="$RWD/addon/state"
    if [ -f "$state_file" ]; then
        sed -i 's/state :loaded/state :unloaded/g' "$state_file"
        while IFS= read -r line; do
            case "$line" in
                *":unloaded"*)
                    package="${line%% *}"
                    cmd ufw set-io-feature 2 "$package" false
                    sh "$RWD/game_conf/config_game.sh" "$package"
                    pm reconcile-secondary-dex-files "$package"
                    cmd ufw settings set-preload-enable "$package" false
                    cmd game reset "$package"
                    am set-standby-bucket --user 0 "$package" frequent
                    cmd game reset --mode 2 --user 0 $package
                    if [ "$b" -lt 13 ]; then
                        device_config delete game_overlay "$package"
                    fi
                    ;;
            esac
        done < "$state_file"
    fi

    if [ "$b" -ge 14 ]; then
        device_config clear_override game android.os.adpf_measure_during_input_event_boost
        device_config clear_override game android.os.adpf_obtainview_boost
        device_config clear_override game android.os.adpf_prefer_power_efficiency
        device_config clear_override game android.os.adpf_platform_power_efficiency
        device_config clear_override game android.server.app.game_default_frame_rate
        device_config clear_override game com.android.graphics.surfaceflinger.flags.game_default_frame_rate
        device_config clear_override game com.android.settings.flags.development_game_default_frame_rate
        device_config clear_override display_manager com.android.server.display.feature.flags.enable_vsync_low_power_vote
    fi

    cmd thermalservice reset
    sm idle-maint run

    sh "$RWD/prop/io_adjustment.sh" &
    sh "$RWD/prop/ql_load.sh" -f "$GAME_LIST" &

    settings put global app_standby_enabled 1
    settings put global activity_starts_logging_enabled 1

    if [ "$adaptive_saver" = "Y" ]; then
        settings put global adaptive_battery_management_enabled 1
        cmd power set-adaptive-power-saver-enabled true
        cmd deviceidle pre-idle-factor 1
    fi

    if [ "$is_logcat_on" = "Y" ]; then
        logcat -G 64k
        logcat -c
    fi

    [ "$speed_mode_on" = "Y" ] && settings put secure speed_mode_enable 0 --user 0
    [ "$temp_limit" = "Y" ] && settings put system rt_enable_templimit true --user 0
    if [ "$bypass_high_temp" = "Y" ]; then
        settings put system tran_temp_battery_warning 1 --user 0
        settings put system tran_default_temperature_index 0 --user 0
    fi
    [ "$fos_hdr_disabler" = "Y" ] && settings put global user_disable_hdr_formats 0

    if [ "$cos_temp_protect" = "Y" ]; then
        settings put secure oppo_high_temperature_protection_status 0
        settings put system oplus_settings_hightemp_protect 0
        settings delete global sys_thermal_control_list
        settings delete system thermal_trace_info_monitor_state
    fi

    [ "$dnd_on" = "Y" ] && cmd notification set_dnd off
    
    if [ "$sched_boost" = "Y" ]; then
        settings put system cloud_turbo_sched_enable false
        settings put system cloud_turbo_sched_enable_core_app_optimizer false
        settings put system cloud_turbo_sched_enable_core_top20_app_optimizer false
        settings put system cloud_schedboost_enable false
        settings put system cloud_turbo_sched_policy_list link
        settings put system cloud_turbo_sched_allow_list ui,animation
    fi
        if [ "$thermal_break" = "Y" ]; then
        settings put system cloud_turbo_sched_thermal_break_enable false
    fi

    if [ "$perf_mode_on" = "Y" ]; then
        settings put system high_performance_mode_on 0 --user 0
        settings put system performance_mode_enable 0 --user 0
        os_detect=$(cat /storage/emulated/0/performance-ai/addon/os_type)
        if [ "$os_detect" = "MIUI" -o "$os_detect" = "HyperOS" ]; then
            settings put system POWER_PERFORMANCE_MODE_OPEN 0
            settings put system power_mode middle
        fi
         if [ "$os_detect" = "ColorOS" ]; then
            settings put system sys_oplus_high_performance_spec 0
        fi
    fi

for pid in $(pgrep "^shell"; pgrep -x "vmt_lite"); do
    
    if [ -e "/proc/$pid/cmdline" ]; then
        
        if grep -q "vmt_lite" "/proc/$pid/cmdline"; then
            renice -n 19 -p "$pid" >/dev/null 2>&1
        else
            chrt -p -i 0 "$pid" >/dev/null 2>&1
            ionice -c 3 -p "$pid" >/dev/null 2>&1
            renice -n 19 -p "$pid" >/dev/null 2>&1
            
        fi
    fi
done
    
    os_detect=$(cat /storage/emulated/0/performance-ai/addon/os_type)
    [ "$os_detect" = "MIUI" -o "$os_detect" = "HyperOS" ] && settings put system light_speed_app ""

} >/dev/null 2>&1

cmd notification post -S bigtext -i "file:///storage/emulated/0/performance-ai/img/banner.png" -t '[Perf AI 状态]' 'PerfAI_Tag' '✅ 均衡模式已激活
• 省电模式：开启 🍃
• 资源使用：已优化
• 后台负载：已减少 ♻️
系统已准备好提供流畅性能！⚡️' >/dev/null 2>&1
