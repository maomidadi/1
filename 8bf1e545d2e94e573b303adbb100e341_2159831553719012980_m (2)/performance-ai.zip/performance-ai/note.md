#warning!!.

# don't modify anything or the will module run abnormaly
# user only allowed to moify game_list.txt, all settings file
# these module is close source don't ask me the source!.
# if you find bug please report by pm @reljawa on telegram and send me the proof
# Don't resell/sell the modules i warn y all
# want copy my code? its allowed but if you copy pastle full the code please give credit for respect 


# important rules for modder!!
1. dont rename the folder,File name and dev/credits name.
2. modder is allowed to add or modify refresh.sh, close.sh, and all prop folders except all files on webui folders without permission
3. don't Ask me if your modification get bugged thats the dwyor(do with you own risk) for modder
4. this module will always free to use and user not forced to pay

# important for user
1. this module have mininum device specification :
- now support for 32/64 bit devices
- Close Source for API Files
- want modify, execute or change? Just read note.md files
- for ram that use for preload recommended use at 6gb minimum ram
- chrome or browser for open webui
- min android version : 10

2. how to solve some problems
- If you experience rebooting issues during installation, turn off the Quick launch option, set shader preload to 1K, and then turn off the egl preloader feature.
- If you experience a reboot when opening the game, try reducing the shader preload size.
- If you experience the problem of touch being too responsive so that the tap becomes a hold, then click the touch settings reset option then press apply.