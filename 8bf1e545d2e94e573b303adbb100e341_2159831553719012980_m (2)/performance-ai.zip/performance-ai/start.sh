#!/system/bin/sh
[ "$(id -u)" -ne 2000 ] && [ "$(id -u)" -ne 0 ] && echo "无 shell 权限。" && exit 1

sys_limiter(){
  RWD="/storage/emulated/0/performance-ai"
  SETTINGS_FILE="$RWD/settings/settings.ini"
  is_lite=$(grep "lite_mode=" "$SETTINGS_FILE" | cut -d "=" -f 2)

  if [ "$is_lite" = "0" ]; then
    setsid sh -c '
      bg_pid=$$
      renice -n 19 "$bg_pid" >/dev/null 2>&1
      ionice -c 3 -p "$bg_pid" >/dev/null 2>&1
      cmd activity set-deterministic-uid-idle --user 0 current true

      launcher=$(pm resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME | cut -d/ -f1 | tail -n1)
      keyboard=$(settings get secure default_input_method | cut -d/ -f1)
      static_whitelist="com.google.android.gms|com.heytap.htms|com.google.android.as|com.android.oemextensions|com.google.android.ext.services|com.google.android.ext.shared|com.oplus.notificationmanager|com.asus.gamewidget"
      
      full_whitelist="$launcher|$keyboard|$static_whitelist"

      pkgs=$(cmd package list packages -s --user 0 | cut -d ":" -f 2 | grep -vE "$full_whitelist")
      count=$(echo "$pkgs" | wc -l)

      JOB='\''p=$1; appops set $p ACTIVITY_RECOGNITION ignore; appops set $p ACTIVITY_RECOGNITION_SOURCE ignore; appops set $p FOREGROUND_SERVICE_SPECIAL_USE ignore; appops set $p GET_ACCOUNTS ignore; appops set $p INSTANT_APP_START_FOREGROUND ignore; appops set $p MONITOR_LOCATION ignore; appops set $p RUN_ANY_IN_BACKGROUND ignore; appops set $p RUN_IN_BACKGROUND ignore; appops set $p RUN_USER_INITIATED_JOBS ignore; appops set $p INTERACT_ACROSS_PROFILES deny; appops set $p START_FOREGROUND ignore; appops set $p SYSTEM_EXEMPT_FROM_HIBERNATION deny; appops set $p SYSTEM_EXEMPT_FROM_POWER_RESTRICTIONS deny; appops set $p LOADER_USAGE_STATS ignore; cmd sensorservice set-uid-state $p idle --user 0; cmd activity make-uid-idle --user current "$p"'\''

      echo "$pkgs" | xargs -n 1 -P 2 sh -c "$JOB" --

      cmd notification post -S bigtext -t "Performance AI" "sys_limiter_done" "成功对 $count 个包应用 appops（白名单重要系统包）。" >/dev/null 2>&1
    ' >/dev/null 2>&1 &
  else
    echo "使用精简模式，跳过 appops"
  fi
}
RWD="/storage/emulated/0/performance-ai"

appops_set_deny() { cmd appops set "$1" "$2" deny; }
appops_set_allow() { cmd appops reset "$1"; }

check_device_compatibility() {
    local android_version=$(getprop ro.build.version.release)
    local device_abi=$(getprop ro.product.cpu.abi)
    local major_version=$(echo "$android_version" | cut -d. -f1)
    is_arm=false
    case "$device_abi" in
        *arm64*|*armeabi*) is_arm=true ;;
    esac
    if [ "$major_version" -lt 10 ] || [ "$is_arm" = false ]; then
        echo "• [错误]: 不支持的设备。"
        if [ "$major_version" -lt 10 ]; then echo "    - 原因: Android 版本 $android_version 不受支持（需要 Android 10+）。"; fi
        if [ "$is_arm" = false ]; then echo "    - 原因: 设备架构 ($device_abi) 不受支持（需要 ARM）。"; fi
        return 1
    else
        echo "• [信息]: 设备兼容: Android $android_version ($device_abi)"
        return 0
    fi
}

os_tunning_setup(){
    local OS_SETTINGS="$RWD/settings/os_settings.ini"
    local xos_usr_exp=$(awk -F "=" '/xos_user_experience/ {print $2}' "$OS_SETTINGS")
    local hos_gme_acc=$(awk -F "=" '/hos_game_adj/ {print $2}' "$OS_SETTINGS")
    local fun_net_acc=$(awk -F "=" '/fos_network_acc/ {print $2}' "$OS_SETTINGS")
    local os_type=$(cat "$RWD/addon/os_type")
    if [ "$xos_usr_exp" = "Y" ]; then
         settings put --user 0 global os_supreme_user_experience 1 >/dev/null 2>&1
         settings put --user 0 system user_experience 1 >/dev/null 2>&1
    fi
    if [ "$hos_gme_acc" = "Y" ]; then
         settings put --user 0 system perf_game_oom_enable 1 >/dev/null 2>&1
         settings put --user 0 system perf_rt_enable true >/dev/null 2>&1
        case "$os_type" in
          MIUI|HyperOS)
            local INSTALLED_PACKAGES=$(mktemp)
            cmd package list packages -3 --user 0 | sed 's/package://' > "$INSTALLED_PACKAGES"
            local verified_games=$(grep -Ff "$INSTALLED_PACKAGES" "$RWD/game_list_true.txt" | paste -sd ',')
            rm "$INSTALLED_PACKAGES"
            if [ -n "$verified_games" ]; then settings put --user 0 system perf_proc_game_List "$verified_games" >/dev/null 2>&1; fi
            ;;
        esac
    fi
    if [ "$fun_net_acc" = "Y" ]; then settings put --user 0 global use_data_network_acclerate 1 >/dev/null 2>&1; fi
    case "$os_type" in
          HiOS|XOS)
            setprop persist.sys.fuse.passthrough.enable true
            setprop persist.sys.fuse.log false
            setprop persist.sys.lmk.reportkills false
            ;;
        esac
}

set_tare() {
    local GAME_LIST="$RWD/game_list_true.txt"
    if command -v cmd >/dev/null 2>&1 && cmd tare help | grep -q "set-vip"; then
        pm list packages -s --user 0 | while read -r line; do
            PKG=$(echo "$line" | cut -f2 -d:)
            cmd tare set-vip 0 "$PKG" false >/dev/null 2>&1
        done
        if [ -f "$GAME_LIST" ]; then
            local INSTALLED_PACKAGES=$(mktemp)
            cmd package list packages -3 --user 0 | sed 's/package://' > "$INSTALLED_PACKAGES"
            grep -Ff "$INSTALLED_PACKAGES" "$GAME_LIST" | while read -r GAME_PKG; do
                [ -n "$GAME_PKG" ] && cmd tare set-vip 0 "$GAME_PKG" true >/dev/null 2>&1
            done
            rm "$INSTALLED_PACKAGES"
        fi
    fi
}

gapps_limiters(){
  local gapps_limiter=$(awk -F "=" '/gapps_limiter/ {print $2}' "$RWD/settings/settings.ini")
  if [ "$gapps_limiter" = "Y" ]; then
    for pkg in $(pm list packages --user 0 | grep '^package:com\.google\.' | sed 's/^package://'); do
      am set-standby-bucket --user 0 "$pkg" restricted >/dev/null 2>&1
      appops_set_deny "$pkg" RUN_ANY_IN_BACKGROUND
    done
  else
    for pkg in $(pm list packages --user 0 | grep '^package:com\.google\.' | sed 's/^package://'); do
      am set-standby-bucket --user 0 "$pkg" working_set >/dev/null 2>&1
      appops_set_allow "$pkg" RUN_ANY_IN_BACKGROUND
    done
  fi
}

wm_logging_disabler(){
    local wm_logging=$(awk -F "=" '/window_logging/ {print $2}' "$RWD/settings/settings.ini")
    if [ "$wm_logging" = "Y" ]; then
    # 致谢 @Dcx400 telegram
      for f in $(dumpsys window | grep "^  Proto:" | sed 's/^  Proto: //' | tr ' ' '\n'; dumpsys window | grep "^  Logcat:" | sed 's/^  Logcat: //' | tr ' ' '\n'); do wm logging disable "$f"; wm logging disable-text "$f"; done
      cmd window logging stop >/dev/null 2>&1
      wm tracing level off >/dev/null 2>&1
      wm tracing size 0 >/dev/null 2>&1
      cmd accessibility stop-trace >/dev/null 2>&1
      cmd input_method tracing stop >/dev/null 2>&1
    fi
}

webui_startup(){
    if ! check_device_compatibility; then exit 1; fi
    echo "• [WEBUI]: 正在打开并处理 webui API。"
    pkill -f /data/local/tmp/server >/dev/null 2>&1
    used_webui_api_setup >/dev/null 2>&1
    nohup /data/local/tmp/server >/dev/null 2>&1 &
    sleep 1
    am start -a android.intent.action.VIEW -d http://localhost:8080
}

clean_kill(){
    PIDS=$(pgrep -f "/data/local/tmp/perf_service_@api")
    if [ -n "$PIDS" ]; then
        for PID in $PIDS; do kill -9 "$PID"; done
    fi
}

chiptune() {
    if grep -q "MT" /proc/cpuinfo; then
        setprop debug.mediatek.appgamepq_compress "1"
        setprop debug.mediatek.disp_decompress "1"
        setprop debug.mediatek.appgamepq "1"
        setprop debug.mediatek.game_pq_enable "1"
        setprop debug.mtklog.netlog.enable "0"
        setprop debug.mtklog.aee.enable "0"
    elif grep -q "Qualcomm" /proc/cpuinfo; then
        setprop debug.gralloc.enable_fb_ubwc "1"
        setprop debug.gralloc.gfx_ubwc_disable "1"
        setprop debug.qctwa.preservebuf "1"
    fi
}

ram_free() {
    local total_ram available_ram
    total_ram=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    available_ram=$(grep MemAvailable /proc/meminfo | awk '{print $2}')
    echo "总内存: $(echo "scale=2; $total_ram/1024/1024" | bc) GB"
    echo "内存使用率: $(echo "scale=2; ($total_ram-$available_ram)*100/$total_ram" | bc)%"
}

get_system_cpu_usage_percentage() {
    read_cpu_stats() {
        read -r _ user nice system idle iowait irq softirq steal guest guest_nice < /proc/stat
        echo $((user+nice+system+idle+iowait+irq+softirq+steal+guest+guest_nice)) "$idle"
    }
    initial_stats=$(read_cpu_stats)
    sleep 0.2
    final_stats=$(read_cpu_stats)
    initial_total_time=$(echo "$initial_stats" | cut -d' ' -f1)
    initial_idle_time=$(echo "$initial_stats" | cut -d' ' -f2)
    final_total_time=$(echo "$final_stats" | cut -d' ' -f1)
    final_idle_time=$(echo "$final_stats" | cut -d' ' -f2)
    delta_total=$((final_total_time - initial_total_time))
    delta_idle=$((final_idle_time - initial_idle_time))
    if [ "$delta_total" -eq 0 ]; then echo "0.00"; else awk "BEGIN {printf \"%.2f\", (100.0 * ($delta_total - $delta_idle) / $delta_total)}"; fi
}

proc_stat_and_usage() {
    pid=$(pgrep -f "/data/local/tmp/perf_service_@api" | head -n 1)
    if [ -z "$pid" ]; then
        echo "性能服务状态: 已停止"
        echo "----------------------------------------"
        echo "未找到服务"
        return 1
    fi
    echo "性能服务状态: 运行中"
    echo "----------------------------------------"
    if [ -f "/proc/$pid/stat" ]; then
        stats=$(cat "/proc/$pid/stat")
        starttime=$(echo "$stats" | awk '{print $22}')
        uptime_seconds=$(awk '{print $1}' /proc/uptime)
        hz=$(getconf CLK_TCK 2>/dev/null || echo 100)
        runtime_seconds=$(awk "BEGIN {printf \"%.0f\", $uptime_seconds - ($starttime / $hz)}")
        [ "$runtime_seconds" -lt 0 ] && runtime_seconds=0
        days=$((runtime_seconds / 86400)); hours=$(( (runtime_seconds % 86400) / 3600 )); minutes=$(( (runtime_seconds % 3600) / 60 )); seconds=$((runtime_seconds % 60))
        read_process_and_system_stats() {
            process_stats=$(cat "/proc/$pid/stat")
            process_utime=$(echo "$process_stats" | awk '{print $14}')
            process_stime=$(echo "$process_stats" | awk '{print $15}')
            read -r _ user nice system idle iowait irq softirq steal guest guest_nice < /proc/stat
            system_total_time=$((user+nice+system+idle+iowait+irq+softirq+steal+guest+guest_nice))
            echo "$process_utime $process_stime $system_total_time"
        }
        initial_cpu_stats=$(read_process_and_system_stats)
        initial_utime=$(echo "$initial_cpu_stats" | cut -d' ' -f1)
        initial_stime=$(echo "$initial_cpu_stats" | cut -d' ' -f2)
        initial_process_time=$((initial_utime + initial_stime))
        initial_system_total_time=$(echo "$initial_cpu_stats" | cut -d' ' -f3)
        sleep 0.1
        final_cpu_stats=$(read_process_and_system_stats)
        final_utime=$(echo "$final_cpu_stats" | cut -d' ' -f1)
        final_stime=$(echo "$final_cpu_stats" | cut -d' ' -f2)
        final_process_time=$((final_utime + final_stime))
        final_system_total_time=$((final_system_total_time - initial_system_total_time))
        delta_process_time=$((final_process_time - initial_process_time)); delta_system_total_time=$((final_system_total_time - initial_system_total_time))
        if [ "$delta_system_total_time" -eq 0 ]; then process_cpu_percent="0.00"; else process_cpu_percent=$(awk "BEGIN {printf \"%.2f\", (100.0 * $delta_process_time / $delta_system_total_time)}"); fi
        if [ -f "/proc/$pid/io" ]; then
            read_bytes=$(grep "read_bytes:" "/proc/$pid/io" | awk '{print $2}' | tr -d '[:space:]')
            write_bytes=$(grep "write_bytes:" "/proc/$pid/io" | awk '{print $2}' | tr -d '[:space:]')
            format_bytes() { awk -v bytes="${1:-0}" 'BEGIN { if (bytes >= 1073741824) printf "%.2f GB", bytes/1073741824; else if (bytes >= 1048576) printf "%.2f MB", bytes/1048576; else if (bytes >= 1024) printf "%.2f KB", bytes/1024; else printf "%d B", bytes; }'; }
            total_io="读取: $(format_bytes "$read_bytes"), 写入: $(format_bytes "$write_bytes")"
        else total_io="读取: 0 B, 写入: 0 B"; fi
        echo "性能服务 PID: $pid"
        echo "已运行时间: $days 天, $hours 小时, $minutes 分钟, $seconds 秒"
        echo "当前 CPU 服务使用率: $process_cpu_percent%"
        echo "总读写服务使用: $total_io"
    else echo "性能服务状态: 错误"; echo "----------------------------------------"; echo "无法读取 PID $pid 的 /proc 文件"; return 1; fi
}

silent_log(){
    prop="$(getprop|cut -f1 -d])";eval "$(echo "$prop"|grep -F '[log.tag'|sed 's/[\/setprop persist\./g'|sed 's/$/ S/g')";eval "$(echo "$prop"|grep -F '[persist.log.tag'|sed 's/[persist\./setprop /g'|sed 's/$/ S/g')";eval "$(echo "$prop"|grep 'log.tag'|sed 's/[\/setprop /g'|sed 's/$/ S/g')";eval "$(seq 999|sed 's/^/logcat -c\&#/g')"
}

api_setup() {
    local api_path="$RWD/api/$(getconf LONG_BIT)"
    local dest_dir="/data/local/tmp/"
    local files_to_process="vmt_lite perf_service_@api ram_manager_api dynamic_path_api swappy_delta_api"
    for file_name in $files_to_process; do
        rm -f "$dest_dir/$file_name"
        if [ -f "$api_path/$file_name" ]; then cp -p "$api_path/$file_name" "$dest_dir/$file_name" && chmod 777 "$dest_dir/$file_name"; fi
    done
    pm grant com.android.shell android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1
}

used_webui_api_setup() {
    local api_path="$RWD/api/$(getconf LONG_BIT)"
    local dest_dir="/data/local/tmp/"
    local files_to_process="server"
    for file_name in $files_to_process; do
        rm -f "$dest_path/$file_name"
        if [ -f "$api_path/$file_name" ]; then cp -p "$api_path/$file_name" "$dest_dir/$file_name" && chmod 777 "$dest_dir/$file_name"; fi
    done
}

api_delete() {
    local dest_dir="/data/local/tmp"
    local files_to_remove_patterns="vmt_lite perf_service_@api server ram_manager_api dynamic_path_api swappy_delta_api"
    for pattern in $files_to_remove_patterns; do find "$dest_dir" -maxdepth 1 -name "*${pattern}*" -delete; done
}

compability_check() {
    local compability_file="$RWD/compability/supported_feature.list"
    mkdir -p "$(dirname "$compability_file")"; > "$compability_file"
    while IFS= read -r full_command; do
        [ -z "$full_command" ] && continue
        is_supported=false
        base_command=$(echo "$full_command" | awk '{print $1}')
        command_args=$(echo "$full_command" | awk '{$1=""; print substr($0,2)}')
        if [ "$base_command" = "am" ]; then if am help 2>&1 | grep -Fq -- "$command_args"; then is_supported=true; fi
        elif [ "$base_command" = "cmd" ]; then
            service=$(echo "$command_args" | awk '{print $1}')
            sub_command=$(echo "$command_args" | awk '{$1=""; print substr($0,2)}')
            if cmd "$service" help 2>&1 | grep -Fq -- "$sub_command"; then is_supported=true; fi
        fi
        if [ "$is_supported" = true ]; then
            echo "$full_command : 支持" >> "$compability_file"
            sed -i "/^[[:space:]]*#.*$full_command/ s/^#*[[:space:]]*//" "$RWD/refresh.sh" "$RWD/close.sh"
        else
            echo "$full_command : 不支持" >> "$compability_file"
            sed -i "/^[[:space:]]*[^#]*$full_command/ s/^/# /" "$RWD/refresh.sh" "$RWD/close.sh"
        fi
    done <<'EOF'
am set-ignore-delivery-group-policy
am clear-ignore-delivery-group-policy
am set-bg-restriction-level
am service-restart-backoff
am set-foreground-service-delegate
am memory-factor
EOF
}

misc_cmd(){ bmgr cancel backups; bmgr enable 0; cmd otadexopt cleanup; cmd package art cleanup; }

load_state(){
    local unload="$RWD/game_list_true.txt"; local load="$RWD/addon/state"; local INSTALLED_PACKAGES=$(mktemp)
    cmd package list packages -3 --user 0 | sed 's/package://' > "$INSTALLED_PACKAGES"
    mkdir -p "$(dirname "$load")"; > "$load"
    grep -Ff "$INSTALLED_PACKAGES" "$unload" | while read -r package; do
        echo "$package state :unloaded" >> "$load"
        sh $RWD/addon/jit_runner.sh "$package"
    done
    rm "$INSTALLED_PACKAGES"
}

write_apk() { cmd package list packages --user 0 | cut -d ':' -f 2 | grep -F -x -f "$RWD/game_list.txt" > "$RWD/game_list_true.txt"; }

clear_log() { > "$RWD/log/scanning.log"; > "$RWD/log/debug.log"; > "$RWD/log/error.log"; rm "$RWD/log/vmtouch_killed_pids.log"; }

install() {
    echo "• [信息]: start.sh 正在启动"
    find "$RWD"/emulated -type f -delete
    rm -rf "$RWD/emulated/isolated"
    if ! check_device_compatibility; then exit 1; fi
    clean_kill
    compability_check >/dev/null 2>&1
    rm -f "$RWD/emulated/swappy_delta_api.pid"
    write_apk
    load_state >/dev/null 2>&1
    api_setup >/dev/null 2>&1
    chiptune >/dev/null 2>&1
    wm_logging_disabler >/dev/null 2>&1
    echo "• [信息]: 正在应用 appops......"
    sys_limiter >/dev/null 2>&1
    echo "• [信息]: appops 应用完成......"
    gapps_limiters >/dev/null 2>&1
    sh "$RWD/prop/ql_load.sh" -C >/dev/null 2>&1
    set_tare >/dev/null 2>&1
    os_tunning_setup >/dev/null 2>&1
    misc_cmd >/dev/null 2>&1
    sh "$RWD/prop/bypass_refresh_rate.sh"
    for script in "$RWD/prop/job_opt.sh" "$RWD/prop/other.sh" "$RWD/prop/launcher.sh" "$RWD/prop/smooth_renderer.sh"; do
       if [ -f "$script" ]; then nice -n 19 sh "$script" >/dev/null 2>&1 & fi
    done
    local SETTINGS_FILE="$RWD/settings/advance_settings.ini"
    local target_frame_rate=$(awk -F "=" '/target_frame_rate/ {print $2}' "$SETTINGS_FILE")
    local advance_target_frame_rate=$(awk -F "=" '/swappy-delta_rt/ {print $2}' "$SETTINGS_FILE")
    local swappy_api="/data/local/tmp/swappy_delta_api"; local swappy_cmd=""
    case "$target_frame_rate" in
        60|90|120|144)
            if [ "$advance_target_frame_rate" = "start-advanced" ]; then swappy_cmd="$swappy_api -ar"
            elif [ "$advance_target_frame_rate" = "start" ]; then swappy_cmd="$swappy_api -or"
            elif [ "$advance_target_frame_rate" = "stop" ]; then echo "跳过 swappy-delta"; swappy_cmd=""
            else echo "未知的 swappy-delta 选项"; swappy_cmd=""; fi ;;
    esac
    if [ -n "$swappy_cmd" ]; then
        echo "• [信息]: swappy-delta_rt 是 '$advance_target_frame_rate'，正在应用 $swappy_cmd"
        $swappy_cmd >/dev/null 2>&1
        local retries=5; local count=0
        while ! pgrep -f "$swappy_api" >/dev/null && [ "$count" -lt "$retries" ]; do
            sleep 1; $swappy_cmd >/dev/null 2>&1; count=$((count+1))
        done
    fi

    nohup /data/local/tmp/perf_service_@api >/dev/null 2>&1 &
    sleep 1
    pids=$(pgrep -f 'swappy_delta_api|perf_service_@api')
    if [ -z "$pids" ]; then exit 0; fi
    for pid in $pids; do renice -n 19 "$pid"; chrt -i -p "$pid" 0 >/dev/null 2>&1; ionice -c 3 -n 7 -p "$pid" >/dev/null 2>&1; done
    if pgrep -f "/data/local/tmp/perf_service_@api" >/dev/null; then
        local pid=$(pgrep -f "/data/local/tmp/perf_service_@api" | head -n 1)
        echo "• [信息]: perf_service_@api 正在运行，PID: $pid"
    else echo "• [错误]: perf_service_@api 启动失败。"; fi
    exit 0 
}

restart_daemon() {
    echo "• [信息]: 正在重启 perf_service_@api 守护进程..."
    clean_kill
    local api_path="$RWD/api/$(getconf LONG_BIT)"
    local dest_file="/data/local/tmp/perf_service_@api"
    if [ -f "$api_path/perf_service_@api" ]; then
        rm -f "$dest_file"; cp -p "$api_path/perf_service_@api" "$dest_file"; chmod 777 "$dest_file"
        nohup "$dest_file" >/dev/null 2>&1 &
        sleep 1
        local pid=$(pgrep -f "/data/local/tmp/perf_service_@api" | head -n 1)
        if [ -n "$pid" ]; then
            echo "• [信息]: 守护进程已启动，PID: $pid。正在应用优先级..."
            renice -n 19 "$pid" >/dev/null 2>&1; chrt -i -p "$pid" 0 >/dev/null 2>&1; ionice -c 3 -n 7 -p "$pid" >/dev/null 2>&1
            echo "• [信息]: 守护进程重启完成。"
        else echo "• [错误]: 启动守护进程失败。"; fi
    else echo "• [错误]: 在 $api_path 未找到源二进制文件"; fi
}

help(){
echo "   ______   ______     ______     ______  "
echo "  /\  == \ /\  ___\   /\  == \   /\  ___\  "
echo "  \ \  _-/ \ \  __\   \ \  __<   \ \  __\ "
echo "   \ \_\    \ \_____\  \ \_\ \_\  \ \_\  "
echo "    \/_/     \/_____/   \/_/ /_/   \/_/   "
echo " "
echo "⚙️ 调教开发 ⚙️"
echo "---------------------"
echo "• 开发者: @reljawa (telegram)" 
echo "• 致谢: @RiProG, @Dcx400, @HoyoSlave @vestia_zeta (telegram)"
echo "• 版本 : 2.2"
echo "• vmtouch 版本 : vmt-lite v2.5 - (由 @reljawa 修改)"
echo "• 开发套件版本 : 1.0(高级)"
echo "• 菜单版本 : 2.0"
echo "-------------------------------------"
echo "• performance Ai 助手"
echo "• 使用 list 命令"
echo "--help 显示所有菜单。"
echo "--install 开始安装 / 运行 perf Ai。"
echo "--uninstall 删除 / 停止 performance Ai。"
echo "--fstrim 在 ( / ) 下所有目录运行 fstrim（黑名单文件夹除外）。"
echo "--reload-settings 在运行时重新加载设置。"
echo "--touch [high|medium|low|reset] 增强触摸响应。"
echo "--driver [game|prelease|angle|reset] 更改你在列表中为游戏使用的驱动程序。"
echo "--silent_log 禁用 / 冻结 android 上的 logcat 功能"
echo "--swappy-delta [start|start-advanced|stop] 在运行时启用帧同步，这将调整 surfaceflinger 偏移量 (测试版)"
echo "--restart-damon 用新的二进制副本重启 perf_service_@api"
echo "--websettings 打开 webui 菜单"
echo "--join 加入我的 telegram 频道。"
echo " "
echo "状态 :"
proc_stat_and_usage
echo "-------------------------------------"
echo "系统当前使用情况详情"
echo "当前 CPU 使用率: $(get_system_cpu_usage_percentage)%"
ram_free
}

uninstall() {
    echo "正在卸载 perf Ai..."
    clean_kill
    /data/local/tmp/swappy_delta_api -s
    pkill -f vmt >/dev/null 2>&1
    sh "$RWD/prop/reset.sh" >/dev/null 2>&1 &
    find "$RWD"/emulated -type f -delete
    rm -rf "$RWD/emulated/isolated"
    api_delete >/dev/null 2>&1
    echo "卸载成功"
}

reload-settings(){
    echo "• 开始重新加载设置..."
    compability_check >/dev/null 2>&1
    wm_logging_disabler >/dev/null 2>&1 &
    gapps_limiters >/dev/null 2>&1
    write_apk
    load_state >/dev/null 2>&1
    os_tunning_setup >/dev/null 2>&1
    sh "$RWD/prop/bypass_refresh_rate.sh"
    for script in "$RWD/prop/job_opt.sh" "$RWD/prop/smooth_renderer.sh" "$RWD/prop/launcher.sh"; do
       if [ -f "$script" ]; then sh "$script" >/dev/null 2>&1 & fi
    done
    write_apk
    echo "• 脚本已重新加载"
}

webui_state(){
    echo "状态 :"
    proc_stat_and_usage
    echo "-------------------------------------"
    echo "系统当前使用情况详情"
    echo "当前 CPU 使用率: $(get_system_cpu_usage_percentage)%"
    ram_free
}

fstrim(){
    local blacklist_folders="my lost+found debug bugreports default.prop product init my_carrier my_company my_custom my_engineering my_heytap my_manifest my_preload my_product my_region my_stock my_version config data_mirror system_ext"
    for folder in $(ls /); do
        skip=false
        for blacklist_folder in $blacklist_folders; do
            case "$folder" in *"$blacklist_folder"*) skip=true; break ;; esac
        done
        if [ "$skip" = false ]; then
            echo "正在对 /$folder 运行 fstrim"
            nice -n 19 sm fstrim "/$folder" 2>/dev/null
            if [ $? -eq 0 ]; then echo "完成"; else echo "在 /$folder 运行 fstrim 出错"; fi
        fi
    done
}

ext_server_setup(){
used_webui_api_setup
nohup /data/local/tmp/server >/dev/null 2>&1 &
}

touch_high(){ settings put secure multi_press_timeout 50; settings put secure long_press_timeout 135; }
touch_medium(){ settings put secure multi_press_timeout 100; settings put secure long_press_timeout 175; }
touch_low(){ settings put secure multi_press_timeout 200; settings put secure long_press_timeout 225; }
touch_reset(){ settings put secure multi_press_timeout 250; settings put secure long_press_timeout 250; }
apply_driver_settings() {
    local game_true="$RWD/game_list_true.txt"
    if [ ! -f "$game_true" ]; then echo "错误: 游戏列表文件 ($game_true) 未找到！"; return 1; fi
    local packages=""
    while IFS= read -r line; do line=$(echo "$line" | tr -d '[:space:]'); [ -n "$line" ] && packages="${packages:+$packages,}$line"; done < "$game_true"
    local sdk_version=$(getprop ro.build.version.sdk)
    local GAME_DRIVER_ALL_APPS="game_driver_all_apps"
    local GAME_OPT_IN_APPS="game_driver_opt_in_apps"
    local GAME_PRE_OPT_IN_APPS="game_driver_prerelease_opt_in_apps"
    if [ "$sdk_version" -ge 31 ]; then
        GAME_DRIVER_ALL_APPS="updatable_driver_all_apps"
        GAME_OPT_IN_APPS="updatable_driver_production_opt_in_apps"
        GAME_PRE_OPT_IN_APPS="updatable_driver_prerelease_opt_in_apps"
    fi
    case "$1" in
        "game")
            settings put global "$GAME_DRIVER_ALL_APPS" "1"
            if [ -n "$packages" ]; then
                settings put global "$GAME_OPT_IN_APPS" "$packages"
                settings put global game_driver_sphal_libraries "libvulkan.so,libEGL.so,libGLESv1_CM.so,libGLESv2.so,libGLESv3.so"
            fi ;;
        "prelease")
            settings put global "$GAME_DRIVER_ALL_APPS" "2"
            if [ -n "$packages" ]; then settings put global "$GAME_PRE_OPT_IN_APPS" "$packages"; fi ;;
        "angle")
            setprop debug.angle.validation false
            settings put global angle_gl_driver_selection_value "angle"
            if [ -n "$packages" ]; then settings put global angle_gl_driver_selection_pkgs "$packages"; fi ;;
        "reset")
            settings delete global angle_gl_driver_all_angle 
            settings delete global angle_gl_driver_selection_value
            settings delete global angle_gl_driver_selection_pkgs
            settings delete global game_driver_all_apps
            settings delete global updatable_driver_all_apps
            settings delete global game_driver_opt_in_apps
            settings delete global updatable_driver_production_opt_in_apps
            settings delete global game_driver_prerelease_opt_in_apps
            settings delete global updatable_driver_prerelease_opt_in_apps ;;
        *) echo "用法: apply_driver_settings {game|prelease|angle|reset}"; return 1 ;;
    esac
}

case "$1" in
    "--install") clear_log; install ;;
    "--uninstall") uninstall ;;
    "--fstrim") fstrim ;;
    "--state") webui_state ;;
    "--reload-settings") reload-settings ;;
    "--websettings") webui_startup; write_apk ;;
    "--silent_log") silent_log ;;
    "--restart-daemon"|"--restart-damon") restart_daemon ;;
    "--ext_setup") ext_server_setup ;;
    "--touch")
        case "$2" in
            high|medium|low|reset) echo "• [信息]: 正在应用 $2 响应触摸"; touch_$2; echo "• [信息]: 成功";;
            *) echo "用法: --touch [high|medium|low|reset]" ;;
        esac ;;
    "--driver")
        case "$2" in
            game|prelease|angle|reset) echo "• [信息]: 正在应用 $2 驱动"; apply_driver_settings "$2"; echo "• [信息]: 成功";;
            *) echo "用法: --driver [game|prelease|angle|reset]" ;;
        esac ;;
    "--swappy-delta")
        local swappy_api_path="/data/local/tmp/swappy_delta_api"
        if [ ! -f "$swappy_api_path" ]; then
            echo "• [信息]: 未找到 swappy_delta_api。正在安装..."
            cp "$RWD/api/$(getconf LONG_BIT)/swappy_delta_api" "$swappy_api_path"
            chmod 777 "$swappy_api_path"
        fi
        case "$2" in
            start) echo "• [初始化]: 正在启动运行 swappy delta Api。(测试版)"; "$swappy_api_path" -r; echo "• [初始化]: 成功运行 swappy delta Api。(测试版)" ;;
            start-advanced) "$swappy_api_path" -ar ;;
            stop) "$swappy_api_path" -s ;;
            *) echo "用法: --swappy-delta [start|start-advanced|stop]" ;;
        esac ;;
    "--help") help ;;
    "--join") nice -n 19 cmd activity start -a android.intent.action.VIEW -d "https://t.me/Youngupdatesource" >/dev/null 2>&1;;
    *) echo "未知选项。使用 --help 显示所有命令" ;;
esac
