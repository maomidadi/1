#!/system/bin/sh
RWD="/storage/emulated/0/performance-ai"
SETTINGS_FILE="$RWD/settings/settings.ini"
API_SETTINGS="$RWD/settings/api_settings.ini"
OS_SETTINGS="$RWD/settings/os_settings.ini"
VMT_LITE_CMD="/data/local/tmp/vmt_lite"
ADV_SETTINGS="$RWD/settings/advance_settings.ini"
TEMP_BASE_DIR="/storage/emulated/0/performance-ai/emulated"
DEFAULT_PID_FILE="$TEMP_BASE_DIR/vmt_lite_libs_dpid"
ram_manager=$(grep "^ram_manager=" "$SETTINGS_FILE" | cut -d "=" -f 2)
dnd_on=$(grep "^dnd_if_gaming=" "$SETTINGS_FILE" | cut -d "=" -f 2)
trim_level=$(grep "^trim_memory_level=" "$SETTINGS_FILE" | cut -d "=" -f 2)
downscale=$(grep "^downscale=" "$ADV_SETTINGS" | cut -d "=" -f 2)
is_lite=$(grep "^lite_mode=" "$SETTINGS_FILE" | cut -d "=" -f 2)
is_logcat_on=$(grep "^logcat_adjuster=" "$SETTINGS_FILE" | cut -d "=" -f 2)
temp_limit=$(grep "^disable_templimit=" "$OS_SETTINGS" | cut -d "=" -f 2)
cos_temp_protect=$(grep "^cos_temp_protect_disabler=" "$OS_SETTINGS" | cut -d "=" -f 2)
speed_mode_on=$(grep "^speed_mode=" "$OS_SETTINGS" | cut -d "=" -f 2)
perf_mode_on=$(grep "^allow_perf_mode=" "$OS_SETTINGS" | cut -d "=" -f 2)
bypass_high_temp=$(grep "^xos_bypass_hightemp_warn=" "$OS_SETTINGS" | cut -d "=" -f 2)
fos_hdr_disabler=$(grep "^fos_hdr_disabler=" "$OS_SETTINGS" | cut -d "=" -f 2)
thermal_break=$(grep "^thermal_breaker=" "$OS_SETTINGS" | cut -d "=" -f 2)
sched_boost=$(grep "^sched_booster=" "$OS_SETTINGS" | cut -d "=" -f 2)
adpative_saver=$(grep "^adaptive_power_saver=" "$API_SETTINGS" | cut -d "=" -f 2)

fps=$(dumpsys display | grep -oE 'fps=[0-9]+(\.[0-9]+)?' | cut -d= -f2 | sort -nu | tail -n 1 | awk '{printf("%.0f\n", $1)}')
window=$(cat "$RWD/emulated/shared_window.perf")
b="$(getprop ro.build.version.release)"

cmd notification post -S bigtext -i "file:///storage/emulated/0/performance-ai/img/banner.png" -t '[Perf AI 状态]' 'PerfAI_Tag' '✅ 优化进行中...
• Perf-AI 状态：运行中
保持最佳表现！⚡️' > /dev/null 2>&1

obb_preloader(){
    dir_obb="/storage/emulated/0/Android/obb/$package"
    if [ -d "$dir_obb" ]; then
        find "$dir_obb" -name "*.obb" -print0 | xargs -0 -r "$VMT_LITE_CMD" -dz
    fi
}

create_temp_file() {
    mkdir -p "$1"
    if [ ! -d "$1" ]; then return 1; fi
    return 0
}

{
if [ "$window" = "com.mobile.legends" ]; then
    targets="com.mobile.legends com.mobile.legends:UnityKillsMe"
else
    targets="$window"
fi

for t in $targets; do
    cmd ufw settings set-boost-proc "$t" 1 true
    cmd ufw settings set-io-feature 2 "$t" true
done

whitelist_str=" "
for t in $targets; do
    pids=$(pidof "$t")
    if [ -n "$pids" ]; then
        whitelist_str="${whitelist_str}${pids} "
    fi
done

for a in $(ps -eo PID,USER | grep u0_ | awk '{print $1}'); do
    
    case "$whitelist_str" in
        *" $a "*)
            ;;
        *)
            cmd ufw settings freeze_one_process "$a"
            cmd activity profile stop "$a"
            am clear-bad-process --user 0 "$a"
            ;;
    esac
done

} >/dev/null 2>&1

Task_preload_system_libs() {
    local settings_egl_preloader=$(grep "^egl_preloader=" "$SETTINGS_FILE" | cut -d'=' -f2 | tr -d '[:space:]')
    
    if [ "$settings_egl_preloader" != "Y" ]; then
        return
    fi

    local egl_type=$(grep "^egl_preloader_type=" "$SETTINGS_FILE" | cut -d'=' -f2 | tr -d '[:space:]')

    if [ -f "$VMT_LITE_CMD" ]; then
        chmod +x "$VMT_LITE_CMD"
    fi
    
    if [ ! -x "$VMT_LITE_CMD" ]; then
        return 1
    fi

    create_temp_file "$TEMP_BASE_DIR"

    if [ "$egl_type" = "game_native" ]; then
       if [ -f "/storage/emulated/0/performance-ai/prop/ql_load.sh" ]; then
           sh /storage/emulated/0/performance-ai/prop/ql_load.sh -L "$window"
           return 0
       fi
    fi

    local total_ram_kb=$(grep 'MemTotal' /proc/meminfo | awk '{print $2}')
    local ram_threshold_kb=5583580
    local lib_arch_dir="lib$(getconf LONG_BIT)"
    local search_dirs="/system/$lib_arch_dir /system/lib"

    if [ ! -d "/system/$lib_arch_dir" ]; then
        search_dirs="/system/lib"
    fi

    if [ -n "$total_ram_kb" ] && [ "$total_ram_kb" -lt "$ram_threshold_kb" ]; then
        find -L $search_dirs -type f \( \
            -name "*vulkan*" -o -name "*GL*" -o -name "*vendor.qti*" -o -name "*mali*" -o \
            -name "*gralloc*" -o -name "*composer*" -name "*gui*" -name "*libprocessgroup.so*" \
            -name "*libc++.so*" -o -name "*libc.so*" \
        \) | "$VMT_LITE_CMD" --wrap -dz -b - -P "$DEFAULT_PID_FILE"
    else
        find -L $search_dirs -type f \( \
            -name "*vulkan*" -o -name "*libvk*" -o -name "*GL*" -o -name "*meow*" -o \
            -name "*libc++.so*" -o -name "*libc.so*" -o -name "*gralloc*" -o -name "*composer*" -o \
            -name "*vendor.qti*" -o -name "*mali*" -name "*gui*" -name "*layers*" -name "*libnativewindow*" \
            -name "*libprocessgroup.so*" \
        \) | "$VMT_LITE_CMD" --wrap -dz -b - -P "$DEFAULT_PID_FILE"
    fi
}


task_1(){
    SENSOR_DATA=$(dumpsys thermalservice)
    echo "$SENSOR_DATA" | grep -Eo 'mName=[^,]+' | cut -d'=' -f2 | sort | uniq | while read sensor; do
        cmd thermalservice inject-temperature "$sensor" none "$sensor" 25
    done
}

task_2() {
    local settings_game_preloading=$(grep "^game_preloading=" "$API_SETTINGS" | cut -d "=" -f 2)
    [[ -z "$window" ]] && return
    
    local game_list_file="$RWD/game_list_true.txt"
    [[ ! -f "$game_list_file" ]] && return
    
    grep -q "^$window$" "$game_list_file" || return
    
    local state_file="$RWD/addon/state"
    local package="$window"
    
    if grep -q "$package state :unloaded" "$state_file"; then
        sed -i "s/$package state :unloaded/$package state :loaded/" "$state_file"
    fi

    if [ "$settings_game_preloading" = "Y" ]; then
        local preload_size=$(grep "^Preload_size_limit=" "$API_SETTINGS" | cut -d "=" -f 2)
        /data/local/tmp/dynamic_path_api "$package" -m "$preload_size" -z
        obb_preloader
    fi
    
    os_detect=$(cat /storage/emulated/0/performance-ai/addon/os_type)
    if [ "$os_detect" = "MIUI" -o "$os_detect" = "HyperOS" ]; then
        settings put system light_speed_app "$package"
    fi

    if [ "$b" -ge 14 ]; then
        cmd game set --mode 2 --downscale "$downscale" --fps "$fps" "$package"
        device_config override game android.os.adpf_measure_during_input_event_boost true
        device_config override game android.os.adpf_obtainview_boost true
        device_config override game android.os.adpf_prefer_power_efficiency false
        device_config override game android.os.adpf_platform_power_efficiency false
        device_config override game android.server.app.game_default_frame_rate false
        device_config override game com.android.graphics.surfaceflinger.flags.game_default_frame_rate false
        device_config override game com.android.settings.flags.development_game_default_frame_rate false
        device_config override display_manager com.android.server.display.feature.flags.enable_vsync_low_power_vote false
    elif [ "$b" -lt 13 ]; then
        cmd game mode 2 --downscale "$downscale" "$package"
        device_config put game_overlay "$package" mode=2,fps="$fps"
    else
        cmd game set --mode 2 --downscale "$downscale" --fps "$fps" "$package"
    fi
    
    cmd activity set-standby-bucket --user 0 "$package" active
    cmd sensorservice set-uid-state "$package" active --user 0
}

task_7() {
    cmd stats clear-puller-cache
    cmd shortcut reset-all-throttling
    sm idle-maint abort
    cmd thermalservice override-status 0
    cmd activity kill-all
    am compact system
}

task_9(){
    sh /storage/emulated/0/performance-ai/prop/io_adjustment.sh
}

run(){
    Task_preload_system_libs
    task_1 >/dev/null 2>&1 &
    task_2 >/dev/null 2>&1 &
    task_9 >/dev/null 2>&1 &
    task_7 >/dev/null 2>&1
    wait
}

run

{
    if cmd wifi status 2>/dev/null | grep -q "Wifi is enabled"; then 
        cmd wifi set-connected-score 60
        cmd wifi set-ipreach-disconnect disabled
    fi

    settings put global app_standby_enabled 0
    settings put global activity_starts_logging_enabled 0

    if [ "$adpative_saver" = "Y" ]; then
        settings put global adaptive_battery_management_enabled 0
        cmd power set-mode 0
        cmd power set-adaptive-power-saver-enabled false
        cmd deviceidle pre-idle-factor 0
    fi

    if [ "$is_logcat_on" = "Y" ]; then
        logcat -G 64K
        logcat -b main -G 128K
        logcat -c
    fi

    [ "$speed_mode_on" = "Y" ] && settings put secure speed_mode_enable 1 --user 0
    [ "$temp_limit" = "Y" ] && settings put system rt_enable_templimit false --user 0

    if [ "$sched_boost" = "Y" ]; then
        settings put system cloud_turbo_sched_enable true
        settings put system cloud_turbo_sched_enable_core_app_optimizer true
        settings put system cloud_turbo_sched_enable_core_top20_app_optimizer true
        settings put system cloud_schedboost_enable true
        settings put system cloud_turbo_sched_policy_list priority
        settings put system cloud_turbo_sched_allow_list ui,game,animation
    fi
        if [ "$thermal_break" = "Y" ]; then
        settings put system cloud_turbo_sched_thermal_break_enable true
    fi
        if [ "$bypass_high_temp" = "Y" ]; then
        settings put system tran_temp_battery_warning 0 --user 0
        settings put system tran_default_temperature_index 0 --user 0
    fi

    if [ "$perf_mode_on" = "Y" ]; then
        settings put system high_performance_mode_on 1 --user 0
        settings put system performance_mode_enable 1 --user 0
        os_detect=$(cat /storage/emulated/0/performance-ai/addon/os_type)
        if [ "$os_detect" = "MIUI" -o "$os_detect" = "HyperOS" ]; then
            settings put system POWER_PERFORMANCE_MODE_OPEN 1
            settings put system power_save_type_performance 0
            settings put system power_mode high
        fi
        if [ "$os_detect" = "ColorOS" ]; then
            settings put system sys_oplus_high_performance_spec 1
        fi
    fi

    [ "$fos_hdr_disabler" = "Y" ] && settings put global user_disable_hdr_formats 1

    if [ "$cos_temp_protect" = "Y" ]; then
        settings put secure oppo_high_temperature_protection_status 0
        settings put system oplus_settings_hightemp_protect -1
        settings put global sys_thermal_control_list ""
        settings put system thermal_trace_info_monitor_state 0
    fi

    [ "$dnd_on" = "Y" ] && cmd notification set_dnd priority
} >/dev/null 2>&1
    if [ "$ram_manager" = "Y" ]; then
        nohup /data/local/tmp/ram_manager_api >/dev/null 2>&1 &
        process_output=$( pidof -f ram_manager_api )
        if [[ ! -z $process_output ]]; then
         chrt -i -p "$process_output" 0
         ionice -c 3 -n 7 -p "$process_output"
         renice -n 10 $process_output
        fi
    fi
  quick_load_status=$(awk -F "=" '/^Quick_load=/ {print $2}' "$API_SETTINGS")
    if [ "$quick_load_status" = "Y" ]; then
        {
            target_dir="$RWD/emulated/isolated"
            current_pid_file="vmt_lite_QL_${window}.pid"
            
            if [ -d "$target_dir" ]; then
                find "$target_dir" -maxdepth 1 -type f -name "vmt_lite_QL_*" ! -name "$current_pid_file" -print0 | xargs -0 -r awk '{print $1}' | xargs -r kill -9 2>/dev/null
            fi
        } &
    else
        echo "快速加载已禁用。"
    fi

setprop debug.junk.procces.pid $(ps -A | grep -E 'trace|perfservice|logd|logcat' | sort -k 5 -nr | head -n 1 | awk '{print $2}')

cmd notification post -S bigtext -i "file:///storage/emulated/0/performance-ai/img/banner.png" -t '[Perf AI 状态]' 'PerfAI_Tag' '✅ 优化完成！
• Perf-AI 状态：成功
保持最佳表现！⚡️' > /dev/null 2>&1
