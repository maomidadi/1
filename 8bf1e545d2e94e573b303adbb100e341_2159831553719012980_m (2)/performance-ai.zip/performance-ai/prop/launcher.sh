#!/system/bin/sh
SETTINGS_FILE="/storage/emulated/0/performance-ai/settings/launcher_settings.ini"

# read
ic_format=$(awk -F "=" '/icon_format/ {print $2}' "$SETTINGS_FILE")
ic_quality=$(awk -F "=" '/icon_quality/ {print $2}' "$SETTINGS_FILE")
cmd shortcut override-config icon_format="$ic_format",icon_quality="$ic_quality"