#!/system/bin/sh

SETTINGS_FILE="/storage/emulated/0/performance-ai/settings/settings.ini"
io_adjust=$(awk -F "=" '/io_adjustment/ {print $2}' "$SETTINGS_FILE")

if [ "$io_adjust" != "active" ]; then
    echo "I/O adjustment is not set to active"
    exit 0
fi

echo "• I/O Priority Adjustment script Version 3.2"
echo "• Date: $(date)"
echo ""

sync

# Get package names and processes
packages=$(ps | awk '/[.][a-z]/{print $2}' | sort -u)
processes=$(ps | awk '/[.][a-z]/{print $9}' | sort -u | cut -d "@" -f 1)

# Load whitelist
whitelist_file="/storage/emulated/0/performance-ai/game_list_true.txt"
whitelist=($(cat "$whitelist_file"))

# Initialize counters and arrays
counter=1
game_hw_pid=""
default_pid=""
background_pid=""

for pkg in $packages; do
    proc=$(echo "$processes" | sed -n "${counter}p")

    # Check if package is in whitelist
    in_whitelist=false
    for item in "${whitelist[@]}"; do
        if [ "$pkg" = "$item" ]; then
            in_whitelist=true
            break
        fi
    done

    if [ "$in_whitelist" = true ]; then
        ((counter++))
        continue
    fi

    # Determine I/O class and priority
    if [[ "$proc" == *"qualcom"* || "$proc" == *"vendor.oplus"* ]]; then
        ionice_class=2
        ionice_priority=3
        category="Hardware Process"
    elif [[ "$proc" == *"trace"* || "$proc" == *"system_server"* ]]; then
        ionice_class=3
        ionice_priority=7
        category="Background Process"
    else
        ionice_class=3
        ionice_priority=6
        category="Default"
    fi

    # Set I/O priority
    if ionice -t -c $ionice_class -n $ionice_priority -p $pkg >/dev/null 2>&1; then
        echo "Optimized I/O for: $proc (Class: $ionice_class, Priority: $ionice_priority)"
        case $category in
            "Hardware Process") game_hw_pid+=" $pkg" ;;
            "Background Process") background_pid+=" $pkg" ;;
            "Default") default_pid+=" $pkg" ;;
        esac
    fi

    ((counter++))
done

# Summary output
echo ""
echo "Optimized Processes:"
echo "Hardware Processes: $game_hw_pid"
echo "Background Processes: $background_pid"
echo "Default Processes: $default_pid"
echo "Process completed!"
