set#!/system/bin/sh
RWD="/storage/emulated/0/performance-ai"
SETTINGS_DIR="$RWD/settings"
ERROR_LOG="$RWD/log/error.log"
SETTINGS_FILE="$SETTINGS_DIR/settings.ini"
API_SETTINGS="$SETTINGS_DIR/api_settings.ini"
GAME_LIST_FILE="$RWD/game_list_true.txt"
OS_SETTINGS="$RWD/settings/os_settings.ini"
b="$(getprop ro.build.version.release)"

pkill -15 -f vmt_lite >/dev/null 2>&1
pkill -f ram_manager_api >/dev/null 2>&1
pkill -f perf_service_@api >/dev/null 2>&1
pkill -f swappy_delta_api >/dev/null 2>&1
sleep 0.5
pkill -9 -f vmt_lite >/dev/null 2>&1
pkill -9 -f perf_service_@api >/dev/null 2>&1
pkill -9 -f swappy_delta_api >/dev/null 2>&1

find "$RWD"/emulated -type f \( -name "*.pid" -o -name "*_dpid" -o -name "*vmtouch_batch.*" -o -name "*_list_*.txt" -o -name "*.willneed" -o -name "*.video" -o -name "cached_libs_list.txt" \) -delete 2>/dev/null
rm -rf "$RWD/emulated/isolated" >/dev/null 2>&1

sys_limiter_reset(){
  if [ ! -f "$SETTINGS_FILE" ]; then return 1; fi
  is_lite=$(grep "lite_mode=" "$SETTINGS_FILE" | cut -d "=" -f 2)
  android_ver=$(getprop ro.build.version.release | sed 's/\..*//')
  if [ "$is_lite" = "0" ]; then
    cmd activity set-deterministic-uid-idle --user current false
    for a in $(cmd package list packages -s --user 0 | cut -d ":" -f 2); do
      cmd appops reset "$a" >/dev/null 2>&1
      cmd sensorservice reset-uid-state "$a" --user 0
      if [ "$android_ver" -ge 13 ]; then
         cmd activity set-bg-restriction-level --user 0 $a adaptive_bucket >/dev/null 2>&1
      fi
    done
  fi
}

jit_write_error_log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Compile Error: Package $1. Reason: $2" >> "$ERROR_LOG"
}

os_tune_reset(){
hos_gme_acc=$(grep "hos_game_adj=" "$OS_SETTINGS" | cut -d "=" -f 2)
if [ "$hos_gme_acc" = "Y" ]; then
 settings put --user 0 system screen_game_mode 0 >/dev/null 2>&1
 settings put --user 0 system perf_game_oom_enable 0 >/dev/null 2>&1
fi
}

jit_revert(){
jit_mode=$(grep "just-in-time-mode=" "$SETTINGS_FILE" | cut -d "=" -f 2)
if [[ $jit_mode == "speed" || $jit_mode == "speed-profile" || $jit_mode == "everything" || $jit_mode == "quicken" ]]; then
  if [[ -f "$GAME_LIST_FILE" ]]; then
    while IFS= read -r package; do
      if [[ -n "$package" ]]; then
        (
        if cmd package compile --reset "$package" >/dev/null 2>&1; then :; else jit_write_error_log "$package" "Failed to compile package."; fi
        ) &
      fi
    done < "$GAME_LIST_FILE"
    wait
  fi
fi
}

un_tare(){
if cmd tare help | grep -q "set-vip"; then cmd tare clear-vip >/dev/null 2>&1; fi
}

main() {
    jit_revert
    un_tare
    sys_limiter_reset
    os_tune_reset
    
    job_opt=$(awk -F "=" '/job_opt/ {print $2}' "$SETTINGS_FILE")
    quick_load_status=$(grep -e "^Quick_load=" "$API_SETTINGS" | cut -d'=' -f2)
    
    if [[ "$job_opt" == "background_restricted" || "$job_opt" == "multitasking_priority" || "$job_opt" == "balanced" || "$job_opt" == "performance" || "$job_opt" == "gaming_priority" || "$job_opt" == "saver" ]]; then
        job_opt="Y"
    else
        job_opt="N"
    fi
    if [ "$job_opt" = "Y" ]; then
        settings delete global job_scheduler_constants >/dev/null 2>&1
        settings delete global job_scheduler_quota_controller_constants >/dev/null 2>&1
        settings delete global app_ops_constants >/dev/null 2>&1
    fi
    
    os_detect=$(cat /storage/emulated/0/performance-ai/addon/os_type)
    if [ "$os_detect" = "MIUI" -o "$os_detect" = "HyperOS" ]; then
     settings put system light_speed_app "" >/dev/null 2>&1
     settings put system POWER_PERFORMANCE_MODE_OPEN 0 >/dev/null 2>&1
     settings put system power_mode middle >/dev/null 2>&1
    fi
    
    if [ "$quick_load_status" = "Y" ]; then
        find "$RWD"/emulated/isolated -type f -name "vmt_lite_QL_*" -exec awk '{print $1}' {} + | xargs -r kill 2>/dev/null
    fi

    if [ "$b" -ge 14 ]; then
        device_config clear_override game android.os.adpf_measure_during_input_event_boost
        device_config clear_override game android.os.adpf_obtainview_boost
        device_config clear_override game android.os.adpf_prefer_power_efficiency
        device_config clear_override game android.os.adpf_platform_power_efficiency
        device_config clear_override game android.server.app.game_default_frame_rate
        device_config clear_override game com.android.graphics.surfaceflinger.flags.game_default_frame_rate
        device_config clear_override game com.android.settings.flags.development_game_default_frame_rate
        device_config clear_override display_manager com.android.server.display.feature.flags.enable_vsync_low_power_vote
    fi
    # cr @HoyoSlave  cmd twik uninstaller
    for a in $(dumpsys game|grep -Eo 'package [^ ]+|Name:[^ ]+'|sed 's/.* //;s/Name://');do
        cmd game reset "$a"&
    done
    cmd package art cleanup >/dev/null 2>&1
    cmd power set-adaptive-power-saver-enabled false >/dev/null 2>&1
    cmd thermalservice reset >/dev/null 2>&1
    cmd dropbox restore-defaults >/dev/null 2>&1
    sm idle-maint stop >/dev/null 2>&1
    am memory-factor reset >/dev/null 2>&1
    
    settings put global app_standby_enabled 1 >/dev/null 2>&1
    settings put global activity_starts_logging_enabled 1 >/dev/null 2>&1
    settings put global adaptive_battery_management_enabled 1 >/dev/null 2>&1
    settings put global battery_stats_constants track_cpu_times_by_proc_state=false
    
    
    cmd deviceidle reset-pre-idle-factor >/dev/null 2>&1
    
    cmd notification post -S bigtext -i "file:///storage/emulated/0/performance-ai/img/banner.png" -t '[Perf AI]' 'PerfAI_Tag' '🗑️ Uninstall Complete
• Cache Cleaned 🧹
• Settings Reverted ⚙️
• Services Stopped 🛑
System restored to default.' > /dev/null 2>&1
}

main "$@"
exit 0
