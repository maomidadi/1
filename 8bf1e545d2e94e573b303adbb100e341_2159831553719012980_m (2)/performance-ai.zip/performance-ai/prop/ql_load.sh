#!/system/bin/sh
RWD="/storage/emulated/0/performance-ai"
API_SETTINGS_FILE="$RWD/settings/api_settings.ini"
VMTOUCH_PATH="/data/local/tmp/vmt_lite"
PID_DIR="/storage/emulated/0/performance-ai/emulated/isolated"
TMP_DIR="/storage/emulated/0/performance-ai/emulated"

usage() {
    echo "Usage: $0 [OPTIONS] [package_name1] [package_name2] ..."
    echo "  package_name: The Android package name (e.g., com.mobile.legends)"
    echo "  -f <file>: A file containing package names, one per line or separated by '|'."
    echo "  -C: Clean up all existing PID files (both QL and NL) and exit."
    echo "  -L: Use Native Library Preload mode (-L -d ). Bypasses Quick_load check."
    echo "      Default mode is Quick Launch (-Q -A), optimized for speed with mlock."
    exit 0
}

cleanup_and_exit() {
    find "${TMP_DIR}" -maxdepth 1 -type f -name "*_list_*.txt" -delete 2>/dev/null
    exit "${1:-1}"
}

cleanup_pids() {
    echo "Cleaning up all PID files in ${PID_DIR}..."
    find "${PID_DIR}" -maxdepth 1 -type f -name "vmt_lite_QL_*.pid" -delete 2>/dev/null
    find "${PID_DIR}" -maxdepth 1 -type f -name "vmt_lite_NL_*.pid" -delete 2>/dev/null
    echo "Cleanup complete."
}

trap "cleanup_and_exit" EXIT SIGINT SIGTERM SIGHUP

if [ "$1" = "-L" ]; then
    MODE="NATIVE_LIB"
    shift 
else
    MODE="QUICK_LOAD"
fi

PACKAGE_NAMES_INPUT=""
PACKAGE_LIST_FILE=""

if [ "$1" = "-C" ]; then
    cleanup_pids
    cleanup_and_exit 0
elif [ "$1" = "-f" ]; then
    if [ -z "$2" ]; then
        echo "Error: -f option requires a file path."
        usage
    fi
    PACKAGE_LIST_FILE="$2"
    shift 2
    if [ -n "$1" ]; then
        echo "Warning: Package names provided as arguments will be ignored when -f is used."
    fi
else
    PACKAGE_NAMES_INPUT="$@"
fi

if [ -n "$PACKAGE_LIST_FILE" ]; then
    if [ ! -f "$PACKAGE_LIST_FILE" ]; then
        echo "Error: Package list file not found: $PACKAGE_LIST_FILE"
        exit 1
    fi
    
    PACKAGE_NAMES_INPUT=""
    while IFS= read -r line || [ -n "$line" ]; do
        processed_line=$(echo "$line" | tr '|' ' ' | sed 's/^[ \t]*//;s/[ \t]*$//' | sed '/^$/d')
        if [ -n "$processed_line" ]; then
            PACKAGE_NAMES_INPUT="$PACKAGE_NAMES_INPUT $processed_line"
        fi
    done < "$PACKAGE_LIST_FILE"
fi

if [ -z "$PACKAGE_NAMES_INPUT" ]; then
    echo "Error: No package names provided."
    usage
fi

if [ "$MODE" = "NATIVE_LIB" ]; then
    echo "Mode: Native Library Preload (-L)"
    echo "Info: This mode runs regardless of the 'Quick_load' setting."
    PID_PREFIX="vmt_lite_NL_"
    TEMP_FILE_PREFIX="nl_list_"
    GET_VMT_COMMAND() {
        echo "setsid \"$VMTOUCH_PATH\" -L \"apk\" -b \"$TEMP_APK_LIST_FILE\" -d -l -P \"$PID_FILE\" >/dev/null 2>&1 &"
    }

elif [ "$MODE" = "QUICK_LOAD" ]; then
    echo "Mode: Quick Launch (-Q)"
    quick_load=$(grep -e "^Quick_load=" "$API_SETTINGS_FILE" | cut -d'=' -f2)

    if [ "$quick_load" != "Y" ]; then
        echo "Quick load is disabled in $API_SETTINGS_FILE. Exiting."
        exit 0
    fi
    PID_PREFIX="vmt_lite_QL_"
    TEMP_FILE_PREFIX="ql_list_"
    GET_VMT_COMMAND() {
        echo "setsid \"$VMTOUCH_PATH\" -Q \"$TEMP_APK_LIST_FILE\" -A -P \"$PID_FILE\" >/dev/null 2>&1 &"
    }
fi

echo "Attempting to process the following packages:"
for pkg_name_loop_var in $PACKAGE_NAMES_INPUT; do
    echo "- $pkg_name_loop_var"
done
echo "---"

mkdir -p "$PID_DIR" || { echo "Error: Failed to create PID directory: $PID_DIR. Check permissions." >&2; exit 1; }

for PACKAGE_NAME in $PACKAGE_NAMES_INPUT; do
    echo "Processing package: ${PACKAGE_NAME}"

    APK_PATHS_RAW=$(cmd package path "${PACKAGE_NAME}" 2>/dev/null)
    if [ -z "$APK_PATHS_RAW" ]; then
        APK_PATHS_RAW=$(pm path "${PACKAGE_NAME}" 2>/dev/null)
    fi

    if [ -z "$APK_PATHS_RAW" ]; then
        echo "Error: Could not retrieve any APK paths for '${PACKAGE_NAME}'. Skipping."
        continue
    fi

    TEMP_APK_LIST_FILE="${TMP_DIR}/${TEMP_FILE_PREFIX}${PACKAGE_NAME}.txt"
    rm -f "$TEMP_APK_LIST_FILE"

    echo "${APK_PATHS_RAW}" | sed 's/^package://' | while IFS= read -r apk_path_candidate; do
        if [ -f "$apk_path_candidate" ] && echo "$apk_path_candidate" | grep -q '\.apk$'; then
            echo "$apk_path_candidate" >> "${TEMP_APK_LIST_FILE}"
        fi
    done

    if [ ! -s "$TEMP_APK_LIST_FILE" ]; then
        echo "Error: No valid .apk file paths were found for '${PACKAGE_NAME}'. Skipping."
        continue
    fi

    PID_FILE="${PID_DIR}/${PID_PREFIX}${PACKAGE_NAME}.pid"

    if [ -f "$PID_FILE" ] && [ -s "$PID_FILE" ]; then
        OLD_PID=$(cat "$PID_FILE")
        if [ -d "/proc/$OLD_PID" ]; then
            CMDLINE=$(cat /proc/$OLD_PID/cmdline 2>/dev/null)
            if echo "$CMDLINE" | grep -q "vmt_lite"; then
                echo "Stopping existing daemon for ${PACKAGE_NAME} (PID: ${OLD_PID})..."
                kill -15 "$OLD_PID" 2>/dev/null
                sleep 0.5
                if [ -d "/proc/$OLD_PID" ]; then
                    kill -9 "$OLD_PID" 2>/dev/null
                fi
            else
                echo "Warning: Stale PID file found ($OLD_PID is not vmt_lite). Removing."
            fi
        fi
        rm -f "$PID_FILE"
    fi

    VMT_COMMAND=$(GET_VMT_COMMAND)

    echo "Launching vmtouch daemon for ${PACKAGE_NAME}..."
    echo "  APK List File: ${TEMP_APK_LIST_FILE}"
    echo "  PID File: ${PID_FILE}"
    echo "  Command: ${VMT_COMMAND}"
    
    eval "$VMT_COMMAND"

    sleep 1

    if [ -f "$PID_FILE" ] && [ -s "$PID_FILE" ]; then
        DAEMON_PID=$(cat "$PID_FILE")
        echo "Daemon for ${PACKAGE_NAME} started successfully with PID: ${DAEMON_PID}"
    else
        echo "Warning: Failed to confirm vmtouch daemon start for ${PACKAGE_NAME}."
        echo "  Try running vmtouch manually: ${VMT_COMMAND}"
    fi
    echo "---"
done

echo "All requested daemons have been processed."
echo "To stop a daemon, use: kill \$(cat ${PID_DIR}/${PID_PREFIX}<package_name>.pid)"
