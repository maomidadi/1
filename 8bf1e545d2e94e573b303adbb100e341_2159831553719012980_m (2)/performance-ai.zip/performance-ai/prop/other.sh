
#!/system/bin/sh
INT="/storage/emulated/0"
RWD="$INT/performance-ai"
SETTINGS_FILE="$RWD/settings/settings.ini"
silent_trace=$(grep -e "^silent_trace=" "$SETTINGS_FILE" | cut -d'=' -f2)
TRACING_DIR="/sys/kernel/tracing"

misc_prop(){ setprop persist.traced_perf.enable false; setprop persist.traced.enable false; setprop debug.systemui.latency_tracking 0; setprop debug.trace_resource_preload 0; setprop debug.track_amkill 0; }
misc_sys(){ settings put global binder_calls_stats "sampling_interval=600000000,detailed_tracking=disable,enabled=false,upload_data=false"; settings put global battery_stats_constants track_cpu_times_by_proc_state=false,track_cpu_active_cluster_time=false,read_binary_cpu_time=false,max_history_files=0,max_history_buffer_kb=0,phone_on_external_stats_collection=false; }
misc_traced_cmd(){ cmd voiceinteraction set-debug-hotword-logging false; dumpsys procstats --stop-pretend-screen; dumpsys procstats --stop-testing; dumpsys procstats --clear; dumpsys procstats --csv-mem crit; cmd display ab-logging-disable; cmd display dwb-logging-disable; cmd migard dump-trace false; cmd migard start-trace false; cmd migard stop-trace true; cmd statusbar tracing stop; cmd autofill set log_level off; cmd activity clear-watch-heap; cmd activity untrack-associations; cmd blob_store idle-maintenance; cmd display dmd-logging-disable; cmd companiondevice remove-inactive-associations; cmd blob_store clear-all-sessions; cmd companiondevice clear-association-memory-cache; cmd looper_stats disable; cmd activity clear-debug-app; cmd jobscheduler monitor-battery off; cmd accessibility stop-trace; cmd greezer debug false; cmd greezer enable true; simpleperf --log fatal --log-to-android-buffer 0; for db_tag in system_server system_server/Subject data_app_wtf storage_trim SYSTEM_BOOT SYSTEM_AUDIT system_server_wtf SYSTEM_LAST_KMSG; do cmd dropbox add-low-priority "$db_tag"; done; cmd dropbox set-rate-limit 9999999; settings put global dropbox_age_seconds 0; settings put global dropbox_max_files 0; }

if [ "$silent_trace" = "true" ]; then
  echo "-  [Proc]: Applying silent Kernel trace"
  echo 0 > "$TRACING_DIR/tracing_on" 2>/dev/null
  echo 0 > "$TRACING_DIR/tracing_enabled" 2>/dev/null
  echo nop > "$TRACING_DIR/current_tracer" 2>/dev/null
  > "$TRACING_DIR/set_event" 2>/dev/null
  echo 1 > "$TRACING_DIR/buffer_size_kb" 2>/dev/null
  for opt in "$TRACING_DIR/options/"*; do case "$(basename "$opt")" in function-trace|stacktrace|userstacktrace|sym-*) echo 0 > "$opt" 2>/dev/null ;; esac; done
  > "$TRACING_DIR/kprobe_events"; > "$TRACING_DIR/uprobe_events"; > "$TRACING_DIR/synthetic_events"
  echo 0 > "$TRACING_DIR/tracing_max_latency"; echo 0 > "$TRACING_DIR/max_graph_depth"; echo 0 > "$TRACING_DIR/function_profile_enabled"
  > "$TRACING_DIR/trace" 2>/dev/null
  > "$TRACING_DIR/trace_pipe" 2>/dev/null
  echo 0 > "$TRACING_DIR/events/enable" 2>/dev/null
  for inst in "$TRACING_DIR/instances/"*; do echo 0 > "$inst/tracing_on" 2>/dev/null; echo nop > "$inst/current_tracer" 2>/dev/null; done 2>/dev/null || true
  echo 0 > /proc/sys/kernel/ftrace_enabled 2>/dev/null
  misc_traced_cmd; misc_prop; misc_sys
  [ "$(cat "$TRACING_DIR/tracing_on" 2>/dev/null)" = "0" ] && echo "✓ Tracing disabled" || echo "⚠ Tracing active"
  [ "$(cat "$TRACING_DIR/current_tracer" 2>/dev/null)" = "nop" ] && echo "✓ Tracer nop" || echo "⚠ Tracer active"
else
  echo "silent_trace is disabled."
fi