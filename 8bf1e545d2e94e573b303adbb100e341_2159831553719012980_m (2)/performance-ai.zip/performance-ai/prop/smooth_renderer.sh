#!/system/bin/sh

#path
LOG="/storage/emulated/0/performance-ai/log/error.log"
SETTINGS_FILE="/storage/emulated/0/performance-ai/settings/render_settings.ini"

renderer=$(grep "hw_renderer=" "$SETTINGS_FILE" | cut -d "=" -f 2)
backend=$(grep "hw_backend_renderer=" "$SETTINGS_FILE" | cut -d "=" -f 2)

if [[ $renderer == "vulkan" || $renderer == "skiavk" || $renderer == "skiagl" || $renderer == "opengl" ]]; then
    if [[ $backend == "threaded" ]]; then
        setprop  debug.renderengine.backend "$renderer""threaded"
        setprop debug.hwui.renderer "$renderer"
    else
        setprop debug.hwui.renderer "$renderer"
        setprop debug.renderengine.backend "$renderer"
    fi
elif [[ $renderer == "default" ]]; then
    echo "Skipping process as mode is set to default."
    setprop debug.hwui.early_preload_gl_context true
else
    echo "Invalid mode: $renderer"
fi

composition=$(grep "hw_composition=" "$SETTINGS_FILE" | cut -d "=" -f 2)

if [[ $composition == "gpu" || $composition == "dyn" || $composition == "hwc" || $composition == "cpu" || $composition == "c2d" || $composition == "mdp" ]]; then
    setprop debug.composition.type "$composition"
elif [[ $composition == "default" ]]; then
    echo "Skipping process as mode is set to default."
else
    echo "Invalid mode: $composition"  >> $LOG
fi
if [ "$composition" == "hwc" ]; then
    setprop debug.hwc.disabletonemapping true
else
    echo "composition is not hwc, skipping the command"
fi

if [ "$renderer" == "skiavk" ]; then
    setprop debug.hwui.initialize_gl_always 0
    setprop debug.hwui.early_preload_gl_context false
else
    echo "Renderer is not Vulkan, skipping the command"
fi
