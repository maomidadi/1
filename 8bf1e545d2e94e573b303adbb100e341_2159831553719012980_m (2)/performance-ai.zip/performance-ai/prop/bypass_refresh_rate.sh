#!/system/bin/sh
SETTINGS_FILE="/storage/emulated/0/performance-ai/settings/display_settings.ini"

# read
device_group=$(awk -F "=" '/device-group/ {print $2}' "$SETTINGS_FILE")
device_refresh_rate=$(awk -F "=" '/device_refresh_rate/ {print $2}' "$SETTINGS_FILE")
bypass_dynamic_refresh_rate=$(awk -F "=" '/bypass_dynamic_refresh_rate/ {print $2}' "$SETTINGS_FILE")
os_detect=$(cat /storage/emulated/0/performance-ai/addon/os_type)

if [[ "$bypass_dynamic_refresh_rate" == "Y" ]]; then
    if [[ "$device_group" == "bbk" ]]; then
        case $device_refresh_rate in
            60)
                settings put system peak_refresh_rate 1
                settings put system min_refresh_rate 1
                settings put secure user_refresh_rate 1
                settings put system max_refresh_rate 1
                ;;
            90)
                settings put system peak_refresh_rate 2
                settings put system min_refresh_rate 2
                settings put secure user_refresh_rate 2
                settings put system max_refresh_rate 2
                ;;
            120)
                settings put system peak_refresh_rate 3
                settings put system min_refresh_rate 3
                settings put secure user_refresh_rate 3
                settings put system max_refresh_rate 3
                ;;
            144)
                settings put system peak_refresh_rate 4
                settings put system min_refresh_rate 4
                settings put secure user_refresh_rate 4
                settings put system max_refresh_rate 4
                ;;
            *)
                echo "Nilai device_refresh_rate tidak valid."
                ;;
        esac
    elif [[ "$device_group" == "ubbk" ]]; then
        case $device_refresh_rate in
            60)
                settings put system peak_refresh_rate 60
                settings put system min_refresh_rate 60
                settings put secure user_refresh_rate 60
                settings put system max_refresh_rate 60
                settings put secure miui_refresh_rate 60
                settings put system tran_refresh_mode 10000
               if [ "$os_detect" = "HONOR" -o "$os_detect" = "MagicOS" ]; then
                settings put global hw_screen_high_freq 60
               fi
                
                ;;
            90)
                settings put system peak_refresh_rate 90
                settings put system min_refresh_rate 90
                settings put secure user_refresh_rate 90
                settings put system max_refresh_rate 90
                settings put secure miui_refresh_rate 90
                settings put system tran_refresh_mode 90
               if [ "$os_detect" = "HONOR" -o "$os_detect" = "MagicOS" ]; then
                settings put global hw_screen_high_freq 90
               fi
                ;;
            120)
                settings put system peak_refresh_rate 120
                settings put system min_refresh_rate 120
                settings put secure user_refresh_rate 120
                settings put system max_refresh_rate 120
                settings put secure miui_refresh_rate 120
                settings put system tran_refresh_mode 120
               if [ "$os_detect" = "HONOR" -o "$os_detect" = "MagicOS" ]; then
                settings put global hw_screen_high_freq 120
               fi
                ;;
            144)
                settings put system peak_refresh_rate 144
                settings put system min_refresh_rate 144
                settings put secure user_refresh_rate 144
                settings put system max_refresh_rate 144
                settings put secure miui_refresh_rate 144
                settings put system tran_refresh_mode 144
               if [ "$os_detect" = "HONOR" -o "$os_detect" = "MagicOS" ]; then
                settings put global hw_screen_high_freq 144
               fi
                ;;
            *)
                echo "Nilai device_refresh_rate tidak valid."
                ;;
        esac
    else
        echo "Nilai device-group tidak dikenali."
    fi
else
    echo "• [status]: bypass refresh rate disabled"
fi
