#!/system/bin/sh

RWD="/storage/emulated/0/performance-ai"
SETTINGS_FILE="$RWD/settings/settings.ini"
is_ram_manager_on=$(awk -F "=" '/ram_manager/ {print $2}' "$SETTINGS_FILE")
android_version=$(getprop ro.build.version.release)

cmd deviceidle pre-idle-factor 2
cmd activity kill-all
cmd deviceidle step light
cmd deviceidle step deep

settings put global display_panel_lpm 1
settings put global app_standby_enabled 0
settings put global always_finish_activities 1

if [ "$is_ram_manager_on" = "Y" ]; then
    device_config put activity_manager use_compaction true
else
    echo "auto compact disable"
fi

os_detect=$(cat /storage/emulated/0/performance-ai/addon/os_type)

    if [ "$os_detect" = "MIUI" -o "$os_detect" = "HyperOS" ]; then
     settings put system power_mode lowest
fi