#!/system/bin/sh

sync

SETTINGS_FILE="/storage/emulated/0/performance-ai/settings/settings.ini"
RWD="/storage/emulated/0/performance-ai"
error_log="$RWD/log/error.log"

write_error_log() {
     echo " [$(date '+%Y-%m-%d %H:%M:%S')] Compile Error: Package $1. Reason: $2" >> "$error_log"
 }

if [ -z "$1" ]; then
    echo "Error: Package name not provided."
    echo "Usage: $0 <package_name>"
    exit 1
fi

game_package="$1"
mode=$(grep "just-in-time-mode=" "$SETTINGS_FILE" | cut -d "=" -f 2)
android_version=$(getprop ro.build.version.sdk)

case "$mode" in
    "speed"|"speed-profile"|"everything"|"quicken")
        echo "Compiling $game_package with mode: $mode"
        
        if [[ "$android_version" -eq 33 ]]; then
            compile_output=$(pm compile --full -r bg-dexopt -m "$mode" -p PRIORITY_INTERACTIVE_FAST "$game_package" 2>&1)
        else
            compile_output=$(pm compile -m "$mode" -r bg-dexopt -f "$game_package" --check-prof false 2>&1)
        fi

        echo "$compile_output"
        
        if echo "$compile_output" | grep -q "Failed to compile"; then
            echo "Compile failed for $game_package."
             write_error_log "$game_package" "Compilation unsuporte."
        fi
        wait
        ;;
    "default")
        echo "Skipping process as mode is set to default."
        ;;
    *)
        echo "Invalid mode: $mode"
         write_error_log "Invalid mode." "$mode"
        ;;
esac

